"""
Searching Phrase dictionary from fail records and return phrase(s).
"""

import scoring_manager
import subprocess, re

class defect_search_engine:

    #Variable to store hit score.
    description_hits_count = 0
    summary_hits_count = 0
    total_records=0
    status = ''
    priority = ''

    #Searching failed value in Phrase dictionary.
    @classmethod
    def search_defect_file_level1(self,catalog_dictionary,search_file):
        result_str = '' #Empty string for storing search results.
        self.total_records = self.total_records + len(catalog_dictionary)
        for keyword  in catalog_dictionary:
            try: #Performing search using find windows command.
                cmd = 'find /I "' + str(keyword) + '"  ' + search_file
                result_str = result_str + re.sub(r'(\|\s{2}\d{5}\s{6}\|)', r'\n\1', subprocess.check_output(cmd))
            except Exception as error_message:

                if "exit status 1" in str(error_message).lower():
                    result_str = result_str

                if "exit status 2" in str(error_message).lower() and "\"" in keyword and "\"\"" not in keyword :
                    keyword =  keyword.replace('"','""')
                    try:
                        cmd = 'find /I "' + str(keyword) + '"  ' + search_file
                        result_str = result_str + re.sub(r'(\|\s{2}\d{5}\s{6}\|)', r'\n\1', subprocess.check_output(cmd))
                    except:
                        result_str = result_str

        if len(result_str) > 0 : #returning result if present else returning 'NO MATCH' phrase
            return str(result_str)
        else:
            return  "NO MATCH"


    #Search defects from level1 result and return defect details with search_phrase , if found.
    @classmethod
    def search_defect_file_level2(self,catalog_dictionary,search_string):
        defect_hit_keyword_dictionary = dict() #Dictionary for storing keywords and defect details.
        defect_id = ''
        search_list = search_string.split("\n")  # Converting defect list(from level1 search) into list for searching all defects one by one.

        for keyword  in catalog_dictionary.keys(): #Searching on the basis of keyword.
            for data in search_list:
                self.summary_hits_count = 0 # Clearing hit count of summary.
                self.description_hits_count = 0 # Clearing hit count of description.
                self.status = ''
                self.priority = ''
                if "|" in data: #Capturing defectid and details and increasing hit count if keywords is found in search string.
                    defect_id = data.split("|")[1]
                    summary = data.split("|")[2].strip()
                    self.status = data.split("|")[4].strip()
                    self.priority = data.split("|")[5].strip()
                    submitter = data.split("|")[6].strip()
                    if str(keyword).upper() in summary.upper(): self.summary_hits_count =  1
                    description = str("|".join(data.split("|")[12:]))
                    if str(keyword).upper() in description.upper(): self.description_hits_count =  1

                if self.summary_hits_count > 0 or self.description_hits_count > 0:
                    scoring_manager_ref = scoring_manager.scoring_manager(self.summary_hits_count,self.description_hits_count, self.status,self.priority)
                    defect_hit_keyword_dictionary.setdefault(keyword,[]).append( ["Defect_id:" +str(defect_id).strip(),"Hit_Score:" + str(scoring_manager_ref.get_total_hit_count()).strip(),"Summary:" + summary,"Status:" + self.status,"Submitter:" + submitter,"Priority:" + self.priority,"dh:" + str(self.description_hits_count),"sh:" + str(self.summary_hits_count),"st:" + str(scoring_manager_ref.get_status_hits()),"p:" + str(scoring_manager_ref.get_priority_hits())])
                else:
                    defect_hit_keyword_dictionary.setdefault(keyword, [])

        return defect_hit_keyword_dictionary

    @classmethod
    def calculate_defect_stats(self,defect_file,avg1):
        NCTA_count = 0
        TTA_count_status = {}
        NCTA_count_status = {}
        TTA_count = 0
        total_count = 0
        with open(defect_file,"r") as defect_Files:
            defect_Files.readline()
            for data in defect_Files:
                total_count +=1

                if "NC Test Automation" in data.split("|")[11]:
                    NCTA_count += 1
                    try:
                        NCTA_count_status[data.split("|")[4].split()[0]]= int(NCTA_count_status[data.split("|")[4].split()[0]]) + 1
                    except:
                        NCTA_count_status[data.split("|")[4].split()[0]] = 1
                if "Telus Test Automation" in data.split("|")[11]:
                    TTA_count += 1
                    try:
                        TTA_count_status[data.split("|")[4].split()[0]]= int(TTA_count_status[data.split("|")[4].split()[0]]) + 1
                    except:
                        TTA_count_status[data.split("|")[4].split()[0]] = 1

        return [total_count,NCTA_count,TTA_count,avg1,NCTA_count_status,TTA_count_status]