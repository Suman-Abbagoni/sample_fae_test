"""
Managing , processing and searching defects for :
a. Investigate error.
b. Env-BackEnd error.
"""

from defect_search_engine import defect_search_engine
from util import config_parser

class defect_engine(object):

    catalog_dictionary = dict()
    defect_file_path = config_parser.parser('Defect_search', 'defect_file')  # Defect file path.

    # Process records and return dictionary with TCs records and search phrases which will be used to search for defects.
    def process_records(self,phase3_tx_ref):
        self.catalog_dictionary = dict() #Clear dictionary.

        for data in phase3_tx_ref.get_records():
            if data.split(";")[0] != "nomatch":#Investigate records(No Error phrase)
                self.catalog_dictionary.setdefault(str(":".join(data.split(";")[0].split(":")[4:])).replace("\\\\","\\"),[]).append(data) #Searching will be done by error_message.
            else:#Records with error phrase.
                self.catalog_dictionary.setdefault(";".join(data.split(";")[9:]),[]).append(data) #Searching will be done by error_phrase.

    # Search defects based on search phrase provided and returns dictionary with TCs records and defect details.
    def search_defects(self):
        catalog_dict_temp = dict() #Collection to return data after searching.


        defect_str = defect_search_engine.search_defect_file_level1(self.catalog_dictionary,self.defect_file_path) #Level1 searching of defects from defect file based on provided keyword.

        if defect_str != "NO MATCH": #If we have match in first level, peform second level search.
            defect_hit_keyword_dictionary = defect_search_engine.search_defect_file_level2(self.catalog_dictionary, defect_str) #Level2 searching of defects from level 1 results based on provided keyword.
            #Creating dictionary with TC records and mapping it with defectid(s) from level2 results.
            for key,value in self.catalog_dictionary.items():
                    catalog_dict_temp[tuple(self.catalog_dictionary[key])] = defect_hit_keyword_dictionary[key] #Mapping defect details with test case record.

        return catalog_dict_temp #Returning dictionary with defect details and TC records.

    def percentage_defect_hit(self,investigate_data,env_data_backend):

        total = 0
        if len(env_data_backend) > 0 and type(env_data_backend) == type(dict()):
            for k , v in env_data_backend.items():
                total += len(k)
        if len(investigate_data) > 0 and type(investigate_data) == type(dict()):
            for k , v in investigate_data.items():
                total += len(k)


        hit_count = 0

        if len(env_data_backend) > 0 and type(env_data_backend) == type(dict()):
            for key, value in env_data_backend.items():
                if len(value) > 0:
                    hit_count = hit_count + len(key)

        if len(investigate_data) > 0 and type(investigate_data) == type(dict()):
            for key, value in investigate_data.items():
                if len(value) > 0:
                    hit_count = hit_count + len(key)


        try:
            avg1 = int(hit_count / float(total) * 100)
        except:
            avg1 = 0




        # try:
        #     with open(config_parser.parser("Defect_search", "defect_hit_rate"), 'r') as old_value : old_avg = old_value.readline().split("%")[0]
        # except:
        #     old_avg = float(0.0)
        # try:
        #     avg_value = (int(avg1) + float(old_avg))/2
        # except:
        #     old_avg = float(0.0)
        #     avg_value = (int(avg1) + float(old_avg)) / 2

        defect_hit_rate = open(config_parser.parser("Defect_search", "defect_hit_rate"), 'a+')
        defect_hit_rate.write(str(avg1) + "\n")
        defect_hit_rate.close()

        return defect_search_engine.calculate_defect_stats(self.defect_file_path, avg1)