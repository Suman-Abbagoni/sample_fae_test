from util import config_parser

class scoring_manager(object):

    SUMMARY_HIT_SCORE = config_parser.parser('Defect_search','summary_hit_score')
    DESCRIPTION_HIT_SCORE = config_parser.parser('Defect_search','description_hit_score')

    CLOSED_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_closed_hit_score')
    CANCELLED_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_cancelled_hit_score')
    FIXED_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_fixed_hit_score')
    TEST_READY_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_testready_hit_score')
    OPEN_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_open_hit_score')
    NEW_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_new_hit_score')
    APPROVED_STATUS_HIT_SCORE = config_parser.parser('Defect_search', 'status_approved_hit_score')

    CRITICAL_PRIORITY_HIT_SCORE = config_parser.parser('Defect_search', 'priority_critical_hit_score')
    HIGH_PRIORITY_HIT_SCORE = config_parser.parser('Defect_search', 'priority_high_hit_score')
    MEDIUM_HIT_SCORE = config_parser.parser('Defect_search', 'priority_medium_hit_score')
    LOW_HIT_SCORE = config_parser.parser('Defect_search', 'priority_low_hit_score')

    summary_hits_count = 0.0
    description_hits_count=0.0
    priority_hits_count = 0.0
    status_hits_count = 0.0

    def __init__(self,summary_hits_count,description_hits_count,status,priority):
        self.set_priority_hits(priority)
        self.set_status_hits(status)
        self.summary_hits_count = summary_hits_count
        self.description_hits_count = description_hits_count

        self.priority_hits_count=self.get_priority_hits()
        self.status_hits_count =self.get_status_hits()
        self.set_description_hit(description_hits_count)
        self.set_summary_hits(summary_hits_count)

    #Assign value to summary_hit count.
    def set_summary_hits(self,summary_hits_count):
        self.summary_hits_count = summary_hits_count * float(self.SUMMARY_HIT_SCORE)


    #Return summary_hit_count value.
    def get_summary_hit(self):
        return self.summary_hits_count

    #Assign value to description_hit_count.
    def set_description_hit(self,description_hits_count):
        self.description_hits_count = description_hits_count * float(self.DESCRIPTION_HIT_SCORE)

    #Return description_hit_count value.
    def get_description_hit(self):
        return self.description_hits_count

        # Assign value to priority_hit count.

    def set_priority_hits(self, priority):
        priority = str(priority.split("-")[1]).lower()
        switcher = {
            "critical": self.CRITICAL_PRIORITY_HIT_SCORE,
            "high": self.HIGH_PRIORITY_HIT_SCORE,
            "medium": self.MEDIUM_HIT_SCORE,
            "low":self.LOW_HIT_SCORE
            }

        self.priority_hits_count =  float(switcher.get(priority,0))



        # Return priority_hit_count value.

    def get_priority_hits(self):
        return self.priority_hits_count

        # Assign value to status_hit_count.

    def set_status_hits(self, status):
        status = str(status).lower().strip()

        switcher = {
            "new": self.NEW_STATUS_HIT_SCORE,
            "open": self.OPEN_STATUS_HIT_SCORE,
            "approved": self.APPROVED_STATUS_HIT_SCORE,
            "fixed":self.FIXED_STATUS_HIT_SCORE,
            "test ready": self.TEST_READY_STATUS_HIT_SCORE,
            "cancelled": self.CANCELLED_STATUS_HIT_SCORE,
            "closed": self.CLOSED_STATUS_HIT_SCORE,
        }

        self.status_hits_count = float(switcher.get(status,0))


        # Return status_hit_count value.

    def get_status_hits(self):
        return self.status_hits_count

    #Return total value after adding both summary and description hit count.
    def get_total_hit_count(self):
        return float(self.get_description_hit()) + float(self.get_summary_hit()) +  float(self.get_status_hits())