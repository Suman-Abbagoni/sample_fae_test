"""
	> python fae.py [command]
		where command 
			p1 for phase one analysis. -> python fae.py p1 thread_name tab_name
			p2 for phase two analysis. -> python fae.py p2 thread_name tab_name
			prod for generating special Production test report. -> python fae.py prod thread_name tab_name
			archive for archive master files (which will be scrubbed and trimmed) -> python fae.py archive
			pad for adding a value in master file(s) at defined position. -> python fae.py pad offset value filepath
			generate address report -> python fae.py addressreport
"""

from inputoutput.io_manager import io_manager
from analysis.analysis_engine import analysis_engine
from reporting.report_manager import report_manager
from global_var import command ,filepath , thread, tab_name
from scrub import archive

def phase1():

	""" 1. io_manager, setup for phase 1 """
	io_manager.phase1_setup();

	""" 2. analysis_engine, execute phase 1 """
	analysis_engine.phase1()

	""" 3. io_manager, write to disk for phase1 """
	io_manager.phase1_write_to_disk()

	""" 4. Appending to master file for phase 1b """
	io_manager.write_master_file()

	"""" 5. report_manager, execute for phase 1 and phase2 """
	if command == "p1":
		report_manager.execution_report()

def phase2():

	""" 6. analysis_engine, execute phase 2 """
	io_manager.phase2_setup()

	""" 7. analysis_engine, execute phase 2 """
	analysis_engine.phase2()

	""" 8. io_manager, write to disk for phase 2 """
	io_manager.phase2_write_to_disk()
	if command == "p2":
		report_manager.execution_report()


def phase3():
	""" 1. io_manager, setup for phase 3"""
	io_manager.phase3_setup()

	""" 2. analysis_engine, execute phase 3 """
	analysis_engine.phase3()

	""" 3. Generating Report """
	if command == "p3":
		report_manager.execution_report()


""" Decide Phases Based on Command Line Arguement """

""" execute phase one  """
if(command == "p1"):
	phase1()

""" Execute phase one and two  """
if (command == "p2"):
	phase1()
	phase2()

""" Execute phase one and two  """
if (command == "p3"):
	phase1()
	phase2()
	phase3()

""" execute for prod  """
if(command == "prod"):

	"""1. IO_Manager - setup  for prod report"""
	io_manager.prod_setup()

	""" 2. Appending to master file for prod report"""
	io_manager.write_master_file()

	""" 3. Generating Report """
	report_manager.execution_report()

"""Execute archiving , scrubbing and cleanup"""
if (command == "archive"):

	"""1. Creating archive folder if not present"""
	archive_obj = archive.archive()

	"""2. Clearing file(s) if provided """
	archive_obj.clean_files()

	"""3. Scrub and Trim provided file(s)"""
	archive_obj.scrub_trim_files()

"""Execute archiving , scrubbing and cleanup"""
if (command == "pad"):
	value = str(tab_name)
	offset  = thread


	"""1. Adding provided value in provided file at defined location"""
	archive.archive.pad(offset , value , filepath)


"""Send address status in email report."""
if (command == "addressreport"):

	""" 1. io_manager, setup for Address report."""
	io_manager.address_report_setup()

	""" 2. analysis_engine, execute address report"""
	analysis_engine.address_report()

	"""" 3. report_manager, execute for Address report generation."""
	report_manager.address_report()

	""" 4. io_manager, write address_report to disk """
	io_manager.address_report_clean_and_write()