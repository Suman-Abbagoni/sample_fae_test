"""
Sending Email from data provided in paramaters like:
email_metadata : Sender and Reciever information. Multiple Reciever can be seprated by ','.
email_subject : Should be string.
email_body : Should be string.
email_body_type: Should be string and its can be plain/text , html etc.
"""

import smtplib
import os
from util.logger_util import logger_util
from ConfigParser import NoSectionError
from ConfigParser import NoOptionError
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from util import config_parser
from global_var import tab_name
from mimetypes import guess_type
from email.mime.base import MIMEBase
from email.encoders import encode_base64

class email_manager(object):


    # send the email for phase 1
    @classmethod
    def phase1and2(self,report_tx_refrence,email_body_type):

        if report_tx_refrence.get_address_flag() == True:
            to_email =  config_parser.parser('Address_check', "email_to") #Email for address report.
        else:
            to_email = self.manage_reciever_email(report_tx_refrence.get_reciever()) #Get Receiver email based on report.

        # Create message container - the correct MIME type is multipart/alternative.
        msg = MIMEMultipart()

        # Defining email metadata.
        msg['Subject'] = report_tx_refrence.get_subject()
        msg['From'] = report_tx_refrence.get_sender()
        msg['To'] = to_email
        msg['Cc'] = report_tx_refrence.get_email_cc()


        #Embedding HTML as body to email.
        part1 = MIMEText(report_tx_refrence.get_emailbody(),email_body_type)
        msg.attach(part1)

        #Picking all files for attaching into an email.
        msg = self.attach_file(msg,report_tx_refrence.get_attachments())

        # Send the message via local SMTP server.
        s = smtplib.SMTP(report_tx_refrence.get_host())

        # sendmail function takes 3 arguments: sender's address, recipient's address
        # and message to send - here it is sent as one string.

      # s.sendmail(report_tx_refrence.get_sender(), to_email.split(","), msg.as_string())
        s.quit()

    #Change Email reciepients list based on Test Suite / Report.
    @classmethod
    def manage_reciever_email(self,to_email):

        try:
            to_email = config_parser.parser(tab_name, "email_to") #Deciding based on tab name.
        except (NoSectionError,NoOptionError): #Not changing if section not present in config.
            logger_util.add_logger().info("Email reciepients not changed")

        return to_email

    #Attaching file to email.
    @classmethod
    def attach_file(self,msg,attach_files):

        for attach_file in attach_files:
            if os.path.isfile(attach_file):
                # attach the file to the email after processing its type
                mimetype, encoding = guess_type(attach_file)
                mimetype = mimetype.split('/', 1)
                fp = open(attach_file, 'rb')
                attachment = MIMEBase(mimetype[0], mimetype[1])
                attachment.set_payload(fp.read())
                fp.close()
                encode_base64(attachment)
                attachment.add_header('Content-Disposition', 'attachment', filename=os.path.basename(attach_file))
                msg.attach(attachment)

        return msg