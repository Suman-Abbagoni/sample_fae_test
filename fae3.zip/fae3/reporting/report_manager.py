"""
Orchestration of records / multiple reports
"""

from reporting.email_manager import email_manager
from reporting import tx_object
from util.logger_util import  logger_util
from util import config_parser

class report_manager(object):



    # Report for phase 1 , 2
    @classmethod
    def execution_report(self):
        # Initilizing transaction object for report.
        report_tx_refrence = tx_object.report_tx_object()

        # email_manager: send email  with email_body_type = html
        email_manager.phase1and2(report_tx_refrence,'html')

        if config_parser.parser('Address_check','address_report_flag').upper() == 'TRUE': #Validating Flag for generating separate address report.
            report_tx_refrence.get_email_for_address() #Changing email content as per address_report.
            if report_tx_refrence.get_address_flag() == True: #Checking if threshold value is achieved.
                email_manager.phase1and2(report_tx_refrence, 'html') #Send email if threshold value is achieved.
            else:
                logger_util.add_logger().info("Separate Address report not generated") #Log if threshold value is not achieved for sending email.


    @classmethod
    def address_report(self):
        # Initilizing transaction object for report.
        report_tx_refrence = tx_object.report_tx_object()

        # email_manager: send email  with email_body_type = html
        email_manager.phase1and2(report_tx_refrence,'plain/text')
