"""
Transaction bean for reporting :
Initializing  all data and meta data.
Getters/Setters - Initializing / returning data OR/and meta data.
"""

from inputoutput.io_manager import io_manager
from reporting.generate_report import generate_report
from util import config_parser
from util.logger_util import logger_util
import datetime
from global_var import tab_name

class report_tx_object(object):

    #  String for Storing email_body , attachment(s) and subject.
    email_report_body = ''
    email_body=''
    hostname = ''
    sender = ''
    reciever = ''
    email_cc=''
    email_subj = ''
    attachment = []
    address_report_flag = False #Flag for defining bad_address_count threshhold value.
    current_day = str(datetime.datetime.now().strftime("%A")) #Picking current day.
    archive_day = config_parser.parser("Address_Status_Report", "archive_day") #Picking day to be archived.

    def __init__(self):

        try:
            if config_parser.parser("fae_report_flag", "suite_report").upper() == "ON":
                self.email_report_body = generate_report.start_report_generation(config_parser.parser("General", "data_path") + "results.txt") #Email report with subject
        except  Exception as ex:
            logger_util.add_logger().info("====No result file present====" + str(ex))  #  result.txt not found.

        try:
            if config_parser.parser("fae_report_flag", "suite_report").upper() == "ON":
                self.email_subj = io_manager.getRecordManager('proddata').get_subject(self.email_report_body[0]) #Separating and tweaking subject in case of prod report.
        except :
            try:
                self.email_subj = self.email_report_body[0] # Separating email subject.
            except Exception as ex:
                logger_util.add_logger().info("====Unable to generate report subject====" + str(ex))  # Error in generating report from result.txt

        try:
            self.email_body = self.email_report_body[1]  # Seprating email body.
        except Exception as ex:
            logger_util.add_logger().info("====Unable to generate report Body====" + str(ex))  # Error in generating report from result.txt

        try:
            if config_parser.parser("fae_report_flag", "fail").upper() == "ON" and tab_name != "ET_SSP_Provide":
                self.email_body = self.email_body + io_manager.getRecordManager('fail').report_creation()  # Merging Fail Records Report.
        except Exception as ex:
            logger_util.add_logger().info("====Fail records report Phase1 not Executed====" + str(ex))  # When we are not executing Phase1.

        try:
            if config_parser.parser("fae_report_flag", "investigate").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager('investigatedata').report_creation()  # Merging 'Data to be investigated' Report
        except Exception as ex:
            logger_util.add_logger().info("====Investigate records report Phase2 not Executed====" + str(ex))  # When we are not executing Phase1.

        try:
            if config_parser.parser("fae_report_flag", "env_portal").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager('env_error_portal').report_creation()
        except Exception as ex:
            logger_util.add_logger().info("====env_error_portal records report Phase2 not Executed====" + str(ex))  # When we are not executing Phase1.

        try:
            if config_parser.parser("fae_report_flag", "env_be").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager('env_error_backend').report_creation()
        except Exception as ex:
            logger_util.add_logger().info("====env_error_backend records report Phase2 not Executed====" + str(ex))  # When we are not executing Phase1.

        try:
            if config_parser.parser("fae_report_flag", "bad_data").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager('dataerror').report_creation()  # Merging 'Errorneous data' Records Report
        except Exception as ex:
            logger_util.add_logger().info("====DataError records report  Phase2 not Executed====" + str(ex))  # When we are not executing Phase1.

        try:
            if config_parser.parser("fae_report_flag", "pass").upper() == "ON" and tab_name != "ET_SSP_Provide":
                self.email_body = self.email_body + io_manager.getRecordManager( 'pass').report_creation()  # Merging Pass Records Report
        except Exception as ex:
            logger_util.add_logger().info("====Pass records report Phase2 not Executed====" + str(ex))  # When we are not executing Phase1.

        try:
            if config_parser.parser("fae_report_flag", "norun").upper() == "ON" and tab_name != "ET_SSP_Provide":
                self.email_body = self.email_body + io_manager.getRecordManager('norun').report_creation()  # Merging No-Run Records Report.
        except Exception as ex:
            logger_util.add_logger().info("====NoRun records report Phase2 not Executed====" + str(ex))  # When we are not executing Phase1.


        try:
            if config_parser.parser("fae_report_flag", "bad_address").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager('badaddress').report_creation()  # Merging 'Bad Address' Records Report
        except Exception as ex:
            logger_util.add_logger().info("====Phase2 - badaddress records report not Executed==== " + str(ex)) #When we are not executing Phase2.



        #Keeping Provides reuse pool report here.
        try:
            if config_parser.parser("fae_report_flag", "provide_pool").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager('order_reuse').report_creation()  # Merging Order-Reuse-Pool Records Report
        except Exception as ex:
            logger_util.add_logger().info("====Pool File append not Executed==== " + str(ex))

            # Keeping TTA Defect report at end.
        try:
            if config_parser.parser("fae_report_flag", "TA_defect_report").upper() == "ON":
                self.email_body = self.email_body + io_manager.getRecordManager(
                        'defect_records').report_creation()  # Merging Defects Records Report
        except Exception as ex:
            logger_util.add_logger().info("==== Defect report not generated ==== " + str(ex))

        try:
            self.email_body = io_manager.getRecordManager('addressdata').email_report()  # Picking  Address Report.
            self.email_subj = io_manager.getRecordManager('addressdata').subject  # Merging Address Report subject.
            if self.current_day == self.archive_day: #Comapring currect day with Archive day (Typically Friday)
                self.attachment.append(io_manager.getRecordManager('addressdata').get_attachment())  # Adding  Attachment for master files.
        except  Exception as ex:

            logger_util.add_logger().info("Address report not executed" + str(ex))


        #Email Metadata
        self.sender = config_parser.parser("General", "email_from")  # Sender email picking from config file.
        self.reciever = config_parser.parser("General","email_to")  # Reciever emails , specify multple emails in config seprated by ',' ,  picking from config file(Can change based on Report later).
        self.hostname =  config_parser.parser("General", "host_name")  # Host-name picking from config file.


    #Returns email subject.
    def get_subject(self):
        return self.email_subj

    # Returns email body.
    def get_emailbody(self):
        return self.email_body

    # Returns Sender email.
    def get_sender(self):
        return self.sender

    # Returns generic Reciepient email.
    def get_reciever(self):
        return self.reciever

    # Returns host URL
    def get_host(self):
        return self.hostname

    #Return all attachments.
    def get_attachments(self):
        return self.attachment

        # Return Boolean flag for sending email for Address report.
    def get_address_flag(self):
        return self.address_report_flag

        # Returns Cc email.
    def get_email_cc(self):
        return self.email_cc

    #Clean and add address related data from transaction object if threshold value is achieved.
    def get_email_for_address(self):
        try:
            if  io_manager.getRecordManager('badaddress').address_email_report():
                self.email_subj = io_manager.getRecordManager('badaddress').get_subject()# Subject for Address report.
                self.email_body = config_parser.parser('Address_check','email_body') + io_manager.getRecordManager('badaddress').report_creation() +  config_parser.parser('Address_check','email_body_note')# Email Body for address report.
                io_manager.getRecordManager('badaddress').clear()  # Clearing address file.
                self.attachment = [] #Clearing attachments.
                self.address_report_flag = True #Set flag to True.
                self.email_cc = config_parser.parser("Address_check", "email_cc")  # Host-name picking from config file.
        except  Exception as ex:
            logger_util.add_logger().info("Bad Address separate email not executed" + str(ex))