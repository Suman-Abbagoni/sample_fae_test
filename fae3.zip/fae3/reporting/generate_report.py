"""
Creating seprate reports based on Test Suite name.
"""

import datetime
import re
import calendar
from util import config_parser
from global_var import tab_name,thread
from analysis.analysis_engine import analysis_engine
from ConfigParser import NoSectionError
from ConfigParser import NoOptionError
from inputoutput.io_manager import io_manager
from util.helper import helper
from collections import OrderedDict
from reporting.create_html import create_html
from util.logger_util import logger_util


class generate_report(object):

    def __init__(self):
        pass

    # Following function will make one line out of multiple lines of same Test Case based on status.
    @classmethod
    def start_report_generation(self, fileName):
        list_without_newline=list() #List for storing data.
        cvsfile=open(fileName, "r")
        lines=cvsfile.readlines()
        i=1
        #Looping through input file.
        while i < len(lines):
            #Create one line for all kind of records.
            if ("PASS" in lines[i] or "FAIL" in lines[i]):
                list_without_newline.append(lines[i])

            else:
                s = len(list_without_newline)-1
                list_without_newline[s]= list_without_newline[s] + lines[i]

            i=i+1

        cvsfile.close()


        #Removing unwanted values from list.
        for list_str in list_without_newline[:]:
            if ( 'Promotions_Discounts_Control' in list_str and 'PASS' in list_str):
                list_without_newline.remove(list_str)
            if ( 'Customer_Contacts_Control' in list_str ):
                list_without_newline.remove(list_str)

        return self.process_and_email(list_without_newline,config_parser.parser("General","data_path")+"compact_file.csv")

    #Count Status and write to file.
    @classmethod
    def count_and_write_file(self,list_str,result_file):

        if 'FAIL' in list_str and 'Dictionary does not contain key' in list_str:
            list_str = list_str.replace('FAIL','No-Run')
            report_obj.countnorun = report_obj.countnorun +1
        elif 'PASS' in list_str:
            report_obj.countpass = report_obj.countpass +1
        elif 'FAIL' in list_str:
            report_obj.countfailure = report_obj.countfailure +1

        list_str = list_str.replace('\n','')
        result_file.write(list_str+"\n")
        report_obj.counttotal=report_obj.counttotal + 1

    #Removing unwanted values , unwanted characters and Writing it to file.
    @classmethod
    def process_and_email(self,list_without_newline, fileName):

        #Getting Empty value.
        ts_name=''
        email_body=''

        #Sorting list.
        list_without_newline = helper.phase1_sort_list(list_without_newline)


        result_file = open(fileName,"w+")

        for list_str in list_without_newline :

            #Calculating Status and create file.
            if (ts_name == list_str.split(";")[0] or ts_name == ''):
                self.count_and_write_file(list_str,result_file)
                ts_name = list_str.split(";")[0]

            #Creating HTML/email_body for test_suites	sequentially.
            elif (ts_name != list_str.split(";")[0]) :
                result_file.close()
                email_body = email_body + self.create_email_body(email_body,ts_name,fileName)
                report_obj.counttotal=0
                report_obj.countfailure=0
                report_obj.countnorun=0
                report_obj.countpass=0
                result_file = open(fileName,"w+")
                ts_name = list_str.split(";")[0]
                self.count_and_write_file(list_str,result_file)
        result_file.close()
        email_body = email_body + self.create_email_body(email_body,ts_name,fileName)

        return self.create_email_data(email_body)  # Calling send email.

    # Creating HTML/email_body for test_suites	sequentially.
    @classmethod
    def create_email_body(self,email_body,ts_name,fileName):
        suite_body = "Total: " + str(report_obj.counttotal) + new_line + "Pass: " + str(report_obj.countpass) + new_line \
                     + "Fail:  " + str(report_obj.countfailure) + new_line + "NoRun: " + str(report_obj.countnorun) #Picking all count for one test suite.

        # HTML for Count value of one TestSuite.
        html_count = "<table border=" + config_parser.parser("Report_CSS","count_border") + " style='font-family:" + config_parser.parser("Report_CSS", "count_font") + ";font-size:" + config_parser.parser("Report_CSS", "count_font_size") + "'>" + "\n"  # Define HTML Border.
        html_count = html_count + "<tbody> \n" + "<tr> \n"
        html_count = html_count + "<td style='" + config_parser.parser("Report_CSS","count_style") + "'> %s" % suite_body
        html_count = html_count + "</tr> \n" + "</tbody> \n" + "</table> \n"

        self.create_subject(ts_name,report_obj.counttotal,report_obj.countpass) #Appending Subject for Email based on Test-Suites.
        #Calling proddata function in case of prod report and flag is enabled.
        try:
            if config_parser.parser(tab_name,"prod").upper()=="TRUE":
                html_output = io_manager.getRecordManager("proddata").generate_html_result(fileName)
            else:
                html_output = self.generate_html_result(fileName) #Keeping normal report in case it is not prod data/test suite.
        except (IndexError,NoOptionError,NoSectionError,AttributeError) :
            html_output =  self.generate_html_result(fileName)
        return   html_count + html_output

    # Creating Subject for Email based on Test-Suites.
    @classmethod
    def create_subject(self,ts_name,counttotal,countpass):
        report_obj.global_subject = report_obj.global_subject + "  " + ts_name.replace('_Control','') + "  (" + str(countpass) +  "/" +  str(counttotal) + ")"

    # Calculating max Thread time using this method. Avoiding HTML parsing and reading it like text file to avoid third party library.
    @classmethod
    def max_thread_time(self):
        final_list = list()
        backup_list = list()
        read_html=open(config_parser.parser("General","data_path")+"\\report.html", 'r')
        try:
            list_timings = read_html.read().split(",[],[{")[1].split("}]]")[0].split("},{")
        except:
            list_timings=[]
        for times in list_timings:
            time= times.split(",")[0].split('":"')[1].replace('"','')
            name_thread = times.split(",")[3].split('":')[1]
            if (re.match('".+Thread[0-9]+"' , name_thread )): #Getting value from list for all Threads.
                final_list.append(time)
                backup_list.append(time)
            else:
                backup_list.append(time)


        if (len(final_list)>0):
            final_list.sort(reverse=True)
            max_thread_time =  final_list[0]
        else:
            try:
                backup_list.sort(reverse=True)
                max_thread_time =  backup_list[0]
            except:
                max_thread_time =  "00:00:00"
        read_html.close()
        return max_thread_time

    @classmethod
    def create_email_data (self,data):
        # Create message container - the correct MIME type is multipart/alternative.
        email_list = list()
        subject =  report_obj.global_subject + " - [" + str(datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')) + "]"
        try:
            with open(config_parser.parser("Defect_search", "defect_hit_rate"), 'r') as f:
                lines = f.read().splitlines()
                last_line = lines[-1]
        except  Exception as ex:
            logger_util.add_logger().info("Defect hit file not present " + str(ex))
        #  HTML for Thread and max time.
        html_count = "<table border=" + config_parser.parser("Report_CSS","count_border") + " style='font-family:" + config_parser.parser("Report_CSS", "count_font") + ";font-size:" + config_parser.parser("Report_CSS","count_font_size") + "'>" + "\n"  # Define HTML Border.
        html_count = html_count + "<tbody> \n" + "<tr> \n"
        html_count = html_count + "<td style='" + config_parser.parser("Report_CSS","count_style") +"'> Threads:  %s" % str( thread) + "\n"
        html_count = html_count + "<br> Runtime:  %s</td>" % str( self.max_thread_time()) + "\n"
        try:

            html_count = html_count + "<br> Total Defects:  %s" % str(analysis_engine.defect_stats[0])
            html_count = html_count + "<br> NCTA Defects:  %s" %   str(analysis_engine.defect_stats[1])
            try:
                html_count = html_count + " (n:%s, " % str(analysis_engine.defect_stats[4]["New"])
            except:
                html_count = html_count + " (n:%s, " % 0
            try:
                html_count = html_count + "a:%s, " % str(analysis_engine.defect_stats[4]["Approved"])
            except:
                html_count = html_count + "a:%s, " % 0
            try:
                html_count = html_count + "o:%s, " % str(analysis_engine.defect_stats[4]["Open"])
            except:
                html_count = html_count + "o:%s, " % 0
            try:
                html_count = html_count + "f:%s, " % str(analysis_engine.defect_stats[4]["Fixed"])
            except:
                html_count = html_count + "f:%s, " % 0
            try:
                html_count = html_count + "tr:%s, " % str(analysis_engine.defect_stats[4]["Test"])
            except:
                html_count = html_count + "tr:%s, " % 0
            try:
                html_count = html_count + "cl:%s, " % str(analysis_engine.defect_stats[4]["Closed"])
            except:
                html_count = html_count + "cl:%s, " % 0
            try:
                html_count = html_count + "cncl:%s, " % str(analysis_engine.defect_stats[4]["Cancelled"])
            except:
                html_count = html_count + "cncl:%s, " % 0
            try:
                html_count = html_count + "d:%s)" % str(analysis_engine.defect_stats[4]["Deferred"])
            except:
                html_count = html_count + "d:%s)" % 0

            html_count = html_count + "<br> TTA Defects:  %s" %  str(analysis_engine.defect_stats[2])
            try:
                html_count = html_count + " (n:%s, " % str(analysis_engine.defect_stats[5]["New"])
            except:
                html_count = html_count + " (n:%s, " % 0

            try:
                html_count = html_count + "a:%s, " % str(analysis_engine.defect_stats[5]["Approved"])
            except:
                html_count = html_count + "a:%s, " % 0

            try:
                html_count = html_count + "o:%s, " % str(analysis_engine.defect_stats[5]["Open"])
            except:
                html_count = html_count + "o:%s, " % 0

            try:
                html_count = html_count + "f:%s, " % str(analysis_engine.defect_stats[5]["Fixed"])
            except:
                html_count = html_count + "f:%s, " % 0

            try:
                html_count = html_count + "tr:%s, " % str(analysis_engine.defect_stats[5]["Test"])
            except:
                html_count = html_count + "tr:%s, " % 0

            try:
                html_count = html_count + "cl:%s, " % str(analysis_engine.defect_stats[5]["Closed"])
            except:
                html_count = html_count + "cl:%s, " % 0

            try:
                html_count = html_count + "cncl:%s, " % str(analysis_engine.defect_stats[5]["Cancelled"])
            except:
                html_count = html_count + "cncl:%s, " % 0

            try:
                html_count = html_count + "d:%s)" % str(analysis_engine.defect_stats[5]["Deferred"])
            except:
                html_count = html_count + "d:%s)" % 0

            html_count = html_count + "<br> Defect hit:"
            html_count = html_count + " %s" %str(analysis_engine.defect_stats[3])
            html_count = html_count + "%</td>\n</tr> \n" + "</tbody> \n" + "</table> \n" + new_line + new_line

        except  Exception as ex:
            html_count = html_count + "\n" + "</tbody> \n" + "</table> \n" + new_line + new_line
            logger_util.add_logger().info("Defect info not present " + str(ex))

        email_body =   html_count + data
        email_list.append(subject)
        email_list.append(email_body)
        return email_list

   # Writing result to HTML.
    @classmethod
    def generate_html_result(self, input_File):

        data_dictionary = OrderedDict()

        # Writing values in HTML from  input file.
        infile = open(input_File, "r")  # Open file in read mode.

        if sum(1 for line in infile) <= 0:
            data_dictionary.setdefault("Test Suite", [])
            data_dictionary.setdefault("Test Case", [])
            data_dictionary.setdefault("Status", [])
            data_dictionary.setdefault("Email", [])
            data_dictionary.setdefault("LocationID", [])
            data_dictionary.setdefault("Error", [])
        infile.close()

        infile = open(input_File, "r")  # Open file in read mode.

        for line in infile:
            row = line.split(";")
            data_dictionary.setdefault("Test Suite", []).append(row[0].replace('_Control',''))
            data_dictionary.setdefault("Test Case", []).append(row[2])
            status = row[4]
            error = str(row[8:])
            if status == "PASS":
                error = error.replace("'None\\n'", "")
            status = '<p style="font-weight: bold ; color:#006400">%s</p>' % status
            if status == "FAIL":
                status = '<p style="font-weight: bold ; color:#8B0000">%s</p>' % status
            data_dictionary.setdefault("Status", []).append(status)
            data_dictionary.setdefault("Email", []).append(row[5])
            data_dictionary.setdefault("Location", []).append(row[6])
            data_dictionary.setdefault("Error", []).append(error)  # Picking all data as it is error message and might have ';' in it.
        infile.close()
        return create_html.html_template(data_dictionary, "null", "")


#Creating Object for this class.
report_obj=generate_report()

#Initializing Global variables.
report_obj.counttotal=0
report_obj.countfailure=0
report_obj.countnorun=0
report_obj.countpass=0
if 'Phase' in tab_name:
	tab_name = str(re.split(r'(\d+)', tab_name)[0]) + " "+ str("".join(re.split(r'(\d+)', tab_name)[1:])).replace(" ","")
elif tab_name == "ET_SSP_Provide":
    tab_name = tab_name
else:
	tab_name = ''

if tab_name == "ET_SSP_Provide":
    report_obj.global_subject ="Env Triage - " + config_parser.parser("General", "Env").split(".")[0] + " -"
if tab_name != "ET_SSP_Provide":
    report_obj.global_subject= calendar.month_name[int(config_parser.parser("General","Release").split(".")[1])] + " " + config_parser.parser("General","Release").split(".")[0] +  " Release - " + tab_name

new_line="<br>"