from util import config_parser
from global_var import tab_name

class create_html(object):

    @classmethod
    def html_template(self,data_dictionary,count,header,header_style=config_parser.parser("Report_CSS", "header_style")):
        # Writing pass result to HTML and returning to report_manager

        html_table = ''  # Empty String for holding html values.
        html_count = ''
        html_body = ''
        key_count = len(data_dictionary.keys())
        # Count value in HTML.
        if count != "null":
            html_count = html_count + "<table border=" + config_parser.parser("Report_CSS","count_border") + " cellpadding='2' style='border-collapse:collapse' ; style='font-family:" + config_parser.parser("Report_CSS", "count_font") + ";font-size:" + config_parser.parser("Report_CSS","count_font_size") + "'>" + "\n"  # Define HTML Border.
            html_count = html_count + "<tbody> \n" + "<tr> \n"
            html_count = html_count + "<td style='" + config_parser.parser("Report_CSS","count_style") + "'>"+header+"= %s</td>" % str(count) + "\n"
            html_count = html_count + "</tr> \n" + "</tbody> \n" + "</table> \n"
            html_table = html_table + html_count

        # HTML body and headers of table.

        html_body = html_body + "<table border=" + config_parser.parser("Report_CSS","header_border") + " cellpadding='2' style='border-collapse:collapse'  style='font-family:" + config_parser.parser("Report_CSS", "header_font") + ";font-size: " + config_parser.parser("Report_CSS","header_font_size") + "'>\n"
        html_body = html_body + "<thead style='" +  header_style + "'>\n"
        for key in data_dictionary:
            if key != "Defect details":
                html_body = html_body + "<th style='%s'>%s</th>\n" % (config_parser.parser("Report_CSS","header_style_second") , str(key))

        if header == "Fail ":
            html_body = html_body + "<th style='%s'>%s</th>\n" % (config_parser.parser("Report_CSS","header_style_second") ,"Root Cause")
            key_count +=1
        if header == "Investigate ":
            html_body = html_body + "<th style='%s'>%s</th>\n" % (config_parser.parser("Report_CSS","header_style_second") ,"Analysis")
            key_count += 1
        html_body = html_body + "</thead>\n"

        for j in range(0,len(data_dictionary.values()[0])):
            html_body = html_body + "<tbody>\n" + "<tr>\n"
            # Writing values in HTML from pass_catalog.
            for  i in range(0 , len(data_dictionary.keys())):

                if data_dictionary.keys()[i] == 'Phrase':
                    html_body = html_body + "<td style='font-size:" + config_parser.parser('Report_CSS','error_font_size') + "' nowrap='nowrap'>%s</td>\n" %data_dictionary[data_dictionary.keys()[i]][j]
                elif data_dictionary.keys()[i] == 'Error':

                    if header == "Fail " or header == "Investigate ":
                        html_body = html_body + "<td style='font-size:" + config_parser.parser('Report_CSS','error_font_size') + "'>%s</td>\n" % data_dictionary[data_dictionary.keys()[i]][j]
                        html_body = html_body + "<td style='font-size:" + config_parser.parser('Report_CSS','error_font_size') + "' nowrap='nowrap'>%s</td>\n" % " "
                    else:
                        html_body = html_body + "<td style='font-size:" + config_parser.parser('Report_CSS','error_font_size') + "'>%s</td>\n" %  data_dictionary[data_dictionary.keys()[i]][j]

                elif data_dictionary.keys()[i] == 'Description':
                    html_body = html_body + "<td> style='font-size:" + config_parser.parser('Report_CSS','error_font_size')+ "%s</td>" % config_parser.parser(tab_name, "description_text_" + data_dictionary[data_dictionary.keys()[1]][j]).split("&&")[0]
                elif data_dictionary.keys()[i] == 'Portal':
                    html_body = html_body + "<td> style='font-size:" + config_parser.parser('Report_CSS','error_font_size')+ "%s</td>" % config_parser.parser(tab_name, "description_text_" + data_dictionary[data_dictionary.keys()[1]][j]).split("&&")[1]
                elif data_dictionary.keys()[i] == 'Success Criteria':
                    html_body = html_body + "<td>style='font-size:" + config_parser.parser('Report_CSS','error_font_size')+ "%s</td>" % config_parser.parser(tab_name, "description_text_" + data_dictionary[data_dictionary.keys()[1]][j]).split("&&")[2]
                elif data_dictionary.keys()[i] == 'Defect details':

                    colspan  = str( key_count - 7)
                    html_body = html_body + self.create_defect_table(data_dictionary[data_dictionary.keys()[i]][j],colspan)
                else:
                    html_body = html_body + "<td  style='font-size:" + config_parser.parser('Report_CSS','error_font_size')+ " ;nowrap='nowrap'>%s</td>\n" % data_dictionary[data_dictionary.keys()[i]][j]

            html_body = html_body + "</tr>\n"
        html_body = html_body + "</tbody>\n" + "</table> <br> <br>"  # HTML Body and table End

        html_table = html_table + html_body  # Appending Body to count value.

        # Passing whole formatted report in once.
        return html_table

    @classmethod
    def create_defect_table(self,data_dictionary,colspan):

        data_dictionary = sorted(data_dictionary, key=lambda x: (str(x).split("', '")[1].split(":")[1]),reverse=True)
        if len(data_dictionary) <= 0:return ''
        header_fields = ['Defect','Status','Priority','Submitter','Summary','Search Analytics']

        defect_html_table= ''
        defect_html_header = "  \n <tr> \n <th  colspan='"+colspan+"' style ='border : "+   config_parser.parser('Defect_search','defect_border')+" '></th> \n"
        for header_data in header_fields:
            defect_html_header = defect_html_header + "<th style='border:" + config_parser.parser('Defect_search',
                                                        'defect_border') + ";text-align:left;padding: 5px 10px;white-space:nowrap;background:#eeeeee;color:#gggggg' >" + header_data + "</th>\n"
        defect_html_header =defect_html_header    +    "</tr>\n"
        # "<th style='border:" + config_parser.parser('Defect_search', 'defect_border') \
        #     + ";text-align:left;padding: 5px 10px;white-space: nowrap;background:#eeeeee;color:#gggggg'>Keyword</th></tr>\n"



        search_string = []
        bg_color = "''"
        for data in data_dictionary:

            if bg_color == "''":
                bg_color = "#F0F8FA"
            else:
                bg_color = "''"
            defect_id = str(data).split("', '")[0].split(":")[1]
            status = str(data).split("', '")[3].split(":")[1]
            submitter = str(data).split("', '")[4].split(":")[1]
            priority = str(data).split("', '")[5].split(":")[1].replace("']","")
            hit_Score  = str(data).split("', '")[1].split(":")[1]
            dh =str(data).split("', '")[6].split(":")[1]
            sh =str(data).split("', '")[7].split(":")[1].replace("']","")
            status_count = str(data).split("', '")[8].split(":")[1].replace("']", "")
            priority_count = str(data).split("', '")[9].split(":")[1].replace("']", "")

            try:
                summary = str("".join(str(data).split("', '")[2].split(":")[1:]))
            except:
                summary = str("".join(str(data).split(', "')[1].split(":")[1:]))

            if  summary[-1:] == "]":
                summary = summary[:-1]
            defect_html_table = defect_html_table + "<tr> \n <td colspan='"+colspan+"' style ='border : "+config_parser.parser \
                ('Defect_search','defect_border')+"'></td> \n <td bgcolor = "+bg_color+" style='border:"+config_parser.parser('Defect_search','defect_border')+ \
                                ";font-size:"+config_parser.parser('Defect_search','defect_font_size')+"'> %s</td>" %defect_id

            defect_html_table = defect_html_table + " <td bgcolor = "+bg_color+" style='border:"+config_parser.parser('Defect_search','defect_border')+\
                                ";font-size:"+config_parser.parser \
                ('Defect_search','defect_font_size')+"'>%s</td>\n" % status
            defect_html_table = defect_html_table + " <td bgcolor = " + bg_color + " style='border:" + config_parser.parser(
                'Defect_search', 'defect_border') + \
                                ";font-size:" + config_parser.parser \
                                    ('Defect_search', 'defect_font_size') + "'>%s</td>\n" % priority
            defect_html_table = defect_html_table + " <td bgcolor = " + bg_color + " style='border:" + config_parser.parser(
                'Defect_search', 'defect_border') + \
                                ";font-size:" + config_parser.parser \
                                    ('Defect_search', 'defect_font_size') + "'>%s</td>\n" % submitter
            defect_html_table = defect_html_table + "\n <td bgcolor = "+bg_color+" style='border:" + config_parser.parser('Defect_search',
                                                                                                   'defect_border') + \
                                ";font-size:" + config_parser.parser('Defect_search',
                                                                     'defect_font_size') + "'>%s</td>\n" % summary
            defect_html_table = defect_html_table + " <td bgcolor = " + bg_color + " style='border:" + config_parser.parser(
                'Defect_search', 'defect_border') + \
                                ";font-size:" + config_parser.parser \
                                    ('Defect_search', 'defect_font_size') + "'>s:"
            defect_html_table = defect_html_table +"%s d:" %sh
            defect_html_table = defect_html_table +"%s st:"  %dh
            defect_html_table = defect_html_table + "%s p:" %status_count
            defect_html_table = defect_html_table + "%s</td></tr>\n" %priority_count
            # defect_html_table = defect_html_table + "\n <td style='border:" + config_parser.parser('Defect_search',
            #                                                                                        'defect_border') + \
            #                     ";font-size:" + config_parser.parser('Defect_search',
            #                                                          'defect_font_size') + "'>%s</td></tr>\n" % hit_Score


            search_string.append(defect_id)

        defect_html_table = defect_html_table + "<tr > \n  <td style='border:" + config_parser.parser('Defect_search',
                                                                                                   'defect_border')+"' colspan='"+colspan+"'></td> " \
        "<td colspan ="+str(len(header_fields))+"  style ='background:#eeeeee;border:none;font-size:"+config_parser.parser('Defect_search','defect_font_size')+ ";text-align:left'>%s</td></tr>"  \
                            % str(" or ".join(search_string))


        defect_html_table = "" + defect_html_header + defect_html_table + "\n"

        return  defect_html_table