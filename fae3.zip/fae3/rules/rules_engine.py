"""
Capturing rules based on phrases for  performing actions later.
"""

from util import config_parser

class rules_engine(object):

    #Search rules from rules dictionary.
    @classmethod
    def search_rules(self,phase2_tx_ref):

        # Process data from rules dictionary based on phrase dictionary records and adding in object.
        phase2_tx_ref.set_records(self.find_action(phase2_tx_ref.get_records()))

        # Returning object to analysis engine.
        return phase2_tx_ref

    #Return dictionary of rules with list of records.
    #If rule not found or phrase was not present. It will go into investigate bucket.
    @classmethod
    def find_action(self,phrase_list):

        # Instance dict variables.
        catalog_dict = {}

        for tc_value , phrase_value_search in phrase_list.items(): #Capturing Action to perform from phrase values.
            if phrase_value_search == "nomatch":
                tc_value = phrase_value_search + ";" + tc_value
                catalog_dict.setdefault("append.investigate.data",[]).append(tc_value) #If value not found - set action to append in investigate data.
            else:
                flag_data = self.search_file(":".join(phrase_value_search.split(":")[:4]))
                if flag_data!= False:
                    tc_value = phrase_value_search.rstrip("\n") + ";" + tc_value
                    for flag_data_value in flag_data:
                        catalog_dict.setdefault(flag_data_value.split(":")[2], []).append(tc_value)  # If value not found - set action to append in investigate data.
                else:
                    tc_value = phrase_value_search + ";" + tc_value
                    catalog_dict.setdefault("append.investigate.data", []).append(tc_value)  # If value not found - set action to append in investigate data.

        return catalog_dict

    #Return all rules for provided phrase and return False if not found.
    @classmethod
    def search_file(self, search_value):

        found_flag = False
        catalog = []
        file_obj = open(config_parser.parser("General", "rules_dictionary"), "r") #Opening file.

        for file_value in file_obj:
            if search_value in file_value:
                catalog.append(file_value.replace(search_value, '').rstrip('\n'))  # Append rules to list.
                #found_flag = True

            # if search_value not in file_value and found_flag == True:
            #     file_obj.close()  # Closing file.
            #     return catalog #Return all values if you stop finding values.
        file_obj.close() #Closing file.

        #Check placed to ensure value is returned if we find value till end of file.
        if len(catalog) > 0:
            catalog = sorted(catalog, key=lambda x: (x.split(":")[1])) #Sort all values found based on index(key)
            return catalog

        # Return False in case nothing is found.
        return False