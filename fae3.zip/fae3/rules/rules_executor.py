"""
Provide Data to based on records type.
Peform actions based on rules.
"""

class rules_executor(object):

    catalog={} #Empty Dictionary.

    #Load data to catalog{}
    def load(self,phase2_tx_ref):
        self.catalog = phase2_tx_ref.get_records() #Pick all records from transaction ref.

    # Return only Bad Data Records.
    def getdataerror(self):
        if "append.data.error" in self.catalog.keys():
            return self.catalog["append.data.error"]
        else:
            return []#return empty list if not found.

    # Return records which needs to be inverstigated.
    def getinvestigatedata(self):
        if "append.investigate.data" in self.catalog.keys():
            return self.catalog["append.investigate.data"]
        else:
            return []#return empty list if not found.

     # Return records only with Bad Addresses.
    def getbadaddress(self):
        if "append.bad.address" in self.catalog.keys():
            return self.catalog["append.bad.address"]
        else:
            return []  # return empty list if not found.

        # Return records only with Bad Addresses.
    def getdata_with_portalenv_errors(self):
        if "append.portalenv.error" in self.catalog.keys():
            return self.catalog["append.portalenv.error"]
        else:
            return []  # return empty list if not found.

            # Return records only with Bad Addresses.
    def getdata_with_backendenv_errors(self):
        if "append.backendenv.error" in self.catalog.keys():
            return self.catalog["append.backendenv.error"]
        else:
            return []  # return empty list if not found.