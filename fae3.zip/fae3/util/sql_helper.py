"""
Peforming SQL operations
a. OPen DB
b. Run Update query
"""
import mysql.connector
from util import config_parser


class sql_helper(object):

    # Safe Mode queries for running update query on MySQL.
    sql_on = "SET SQL_SAFE_UPDATES = 0;"
    sql_off = "SET SQL_SAFE_UPDATES = 1;"
    resultsdata = [] #Empty list for storing records.

    #Executing Update query - Reusable generic function.
    @classmethod
    def update_query(self,queries):
        db = self.connect_sql() #Connect DB
        cursor = db.cursor() #Initialize cursor.
        # execute SQL query using execute() method.
        cursor.execute(self.sql_on) #Disable safe mode.
        for query in queries:
            cursor.execute(query) #Execute queries/query.
        cursor.execute(self.sql_off) #Enable safe mode.
        self.close_sql(db)          #Close DB connection.
        return str(cursor.rowcount) #Return number of rows udpated.

    @classmethod
    def select_query(self,queries):
        self.resultsdata = []
        text="\n"
        new_line = "\n"
        db = self.connect_sql() #Connect DB
        # Reading queries and executing.
        cursor = db.cursor() #Initialize cursor.
        for query in queries:
            cursor.execute(query) # execute SQL query using execute() method.
            result = [i[0] for i in cursor.description] #Pick data header .
            all = cursor.fetchall() #Fetch all data.
            #Put all data in list.
            self.resultsdata.append(result)
            self.resultsdata.append(all)

        # disconnect from server
        self.close_sql(db)
        return self.resultsdata #Return list containing SQL data.


    @classmethod
    def connect_sql(self):
        # Open database connection
        db =mysql.connector.connect(host=config_parser.parser("Address_Status_Report","sql_host"), user=config_parser.parser("Address_Status_Report","sql_user"),
                                    password=config_parser.parser("Address_Status_Report","sql_password"), database=config_parser.parser("Address_Status_Report","schema"))
        return db #Return Db instance.

    @classmethod
    def close_sql(self,db):
        #Commit sql.
        db.commit()
        # disconnect from server
        db.close()