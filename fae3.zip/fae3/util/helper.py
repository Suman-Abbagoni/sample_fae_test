"""
Contains Helper Methods required for particular operation(s)
a. Sort list for Phase1
b. Sort list for Phase2
c. zip files
"""

from decimal import Decimal
import zipfile
from os.path import basename
from global_var import tab_name


class helper(object):

    @classmethod
    def phase1_sort_list(self,catalog_list): #Sort for all records except Phase2 specific records.
        # Sorting based on Suite	, Tab  and finally based on row number in xlsx
        catalog_list = [catalog_list_values.replace('provide', 'Provide').replace('Modify', 'modify').replace('Suspend','suspend').replace('Disconnect', 'z$|&zdisconnect')  for catalog_list_values in catalog_list]#Changing to lowercase in order to sort.

        if tab_name == "Targeted_Sanity":
            catalog_list = [catalog_list_values.replace('SSP_RES_Sanity_Control', '1SSP_RES_Sanity_Control').replace('CSR_RES_Sanity_Control', '2CSR_RES_Sanity_Control')for catalog_list_values in catalog_list]  # Changing to lowercase in order to sort.
            catalog_list = sorted(catalog_list,key=lambda x: (  x.split(";")[0] , x.split(";")[1], Decimal(x.split(";")[3]) ))#Sorting with Lambda.
            catalog_list = [catalog_list_values.replace('1SSP_RES_Sanity_Control', 'SSP_RES_Sanity_Control').replace('2CSR_RES_Sanity_Control', 'CSR_RES_Sanity_Control') for catalog_list_values in catalog_list]  # Changing to lowercase in order to sort.
        else:
            catalog_list = sorted(catalog_list, key=lambda x: (x.split(";")[0], x.split(";")[1], Decimal(x.split(";")[3])))  # Sorting with Lambda.
        catalog_list = [catalog_list_values.replace('modify', 'Modify').replace('suspend',
                                                                                'Suspend').replace('z$|&zdisconnect', 'Disconnect') for catalog_list_values in catalog_list]#Reverting above modification(s).

        return catalog_list

    @classmethod
    def phase2_sort_list(self,catalog_list): #Sort for all records specific to Phase2 except bad address data.
        # Sorting based on Suite	, Tab  and finally based on row number in xlsx
        catalog_list = [catalog_list_values.replace('provide', 'Provide').replace('Modify', 'modify').replace('Suspend',
                                                                                                              'suspend').replace('Disconnect', 'z$|&zdisconnect')  for catalog_list_values in catalog_list]#Changing to lowercase in order to sort.
        catalog_list = sorted(catalog_list, key=lambda x: (x.split(";")[1], x.split(";")[2], Decimal(x.split(";")[4])))#Sorting with Lambda.
        catalog_list = [catalog_list_values.replace('modify', 'Modify').replace('suspend',
                                                                                'Suspend').replace('z$|&zdisconnect', 'Disconnect') for catalog_list_values in catalog_list]#Reverting above modification(s).

        return catalog_list

    @classmethod
    def zip_file(self,zipfilepath,filenames): #Zip all provided files and place it in mentioned zipfilepath.
        zf = zipfile.ZipFile(zipfilepath, "w", zipfile.ZIP_DEFLATED) #Opening zip file.
        for filename in filenames:
            zf.write(filename, basename(filename)) #Writing zip file(s).

        zf.close() #Closing zip file.