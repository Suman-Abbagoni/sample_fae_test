"""
Cleanup all master files after performing backup(copy/append)in archive folder.
Prepended with release year and month (which is picked from config file).
"""

import os
from shutil import copyfile , copyfileobj
import config_parser

class after_release_cleanup(object):
    path = config_parser.parser('General', 'phase2_data_path') #Dir path of master files.
    archive_path = path + "archive\\" #Archive path of master files.

    def __init__(self):
        self.folder_check() #Creating archive folder if not present.

        #Copying or Appending master file(s) data to archive file(s)
        self.copy_file("badaddress.csv")
        self.copy_file("investigatedata.csv")
        self.copy_file("dataerror.csv")
        self.copy_file("order_reuse_pool.csv")

        #Clearing all master file(s).
        self.clear_files("badaddress.csv")
        self.clear_files("investigatedata.csv")
        self.clear_files("dataerror.csv")
        self.clear_files("order_reuse_pool.csv")



    def folder_check(self):
        if not os.path.exists(self.archive_path):
            os.makedirs(self.archive_path)


    #Method for copying file from one dir to another.
    def copy_file(self,filename):
        #Copying file if source file is present but destination file is not present.
        if not os.path.exists( self.archive_path + config_parser.parser("General", "Release") + "." + filename) \
                and os.path.exists(self.path + filename):
            copyfile(self.path + filename, self.archive_path +  config_parser.parser("General", "Release")
                     + "." + filename) #Copying file object using shutil

        #Appending data to destination file if source file is present and destination file is also present.
        elif os.path.exists( self.archive_path + config_parser.parser("General", "Release") + "." + filename) \
                and os.path.exists(self.path + filename):
            with open(self.archive_path + config_parser.parser("General", "Release") + "." + filename , "ab") \
                    as dest: #Opening destination file in write mode.
                with open(self.path + filename, "rb") as src:#Opening source file in read mode.
                    copyfileobj(src,dest) #Copying file object using shutil


    #Method for clearing all data from a file.
    def clear_files(self,filename):
        with open(self.path + filename, 'w'): pass