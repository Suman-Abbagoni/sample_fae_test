"""
Transaction bean for phase2:
Setters / Getters - Initalizing and returning data.
"""

class analysis_engine_tx_object(object):

    #Declaring class variables (Using namescope)
    records = ''

    def set_records(self, records):
        self.records = records #Add  records.

    def get_records(self):
        return self.records #Return records added before.