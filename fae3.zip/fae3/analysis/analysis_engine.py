"""
Identifying type of Records and process it.
"""

from inputoutput.io_manager import io_manager
from search_engine import search_engine
from rules.rules_engine import rules_engine
from util import analysis_engine_tx_object


class analysis_engine(object):

    fail = ''
    inputManager = ''
    investigate_data=''
    env_data_backend=''
    defect_stats = []

    """
    Phase1 : Capturing  records  categories via inputManager and processing it from Record_Manager.
    """

    @classmethod
    def phase1(self):

        # 1. Get references to the record managers
        passManager = io_manager.getRecordManager('pass')
        failManager = io_manager.getRecordManager('fail')
        norunManager = io_manager.getRecordManager("norun")
        orderreusepoolManager = io_manager.getRecordManager("order_reuse")
        self.inputManager = io_manager.getRecordManager('input')

        #2. input manager, give me a list of pass records
        pass_ = self.inputManager.getPassDictionary()

        # 3. Pass the pass-dictionary to the pass manager for processing
        passManager.process(pass_)

        # 4. input manager, give me a dictionary of fail  records
        self.fail = self.inputManager.getFailDictionary()

        # 5. Pass the fail-dictionary to the fail manager for processsing
        failManager.process(self.fail)

        # 6. input manager, give me a dictionary of no-run records
        norun = self.inputManager.getNoRunDictionary()

        # 7. Pass the fail-dictionary to the no-run manager for processsing
        norunManager.process(norun)

        # 8. Pass the pass-dictionary to the order-reuse-pool manager for  adding in pool if required.
        orderreusepoolManager.process(pass_)

    """
    Phase2 : Performing Actions based on rules. Txn object have all data and attributes for performing operations.
    """

    @classmethod
    def phase2(self):

        # 1. Get references to the record managers for phase2 execution.
        rulesexecutor = io_manager.getRecordManager('rulesexecutor')
        data_error_manager = io_manager.getRecordManager('dataerror')
        bad_address_manager = io_manager.getRecordManager('badaddress')
        env_data_portal_manager = io_manager.getRecordManager('env_error_portal')
        env_data_backend_manager = io_manager.getRecordManager('env_error_backend')  # Env error backend instance.
        investigate_data_manager = io_manager.getRecordManager('investigatedata')  # Env error instance

        # 2. Initilazing transaction refrence.
        analysis_engine_tx_ref = analysis_engine_tx_object.analysis_engine_tx_object()

        # 3. Fail records in txn ref.
        analysis_engine_tx_ref.set_records(self.fail)

        #4. Searching phrase in dict. based on fail records.
        analysis_engine_tx_ref = search_engine.search_phrase_dict(analysis_engine_tx_ref)

        # 5. Capturing rules based on actions provided.
        analysis_engine_tx_ref = rules_engine.search_rules(analysis_engine_tx_ref)

        #6. Load records
        rulesexecutor.load(analysis_engine_tx_ref)

        # 7. Get All Errorneous data.
        bad_data =  rulesexecutor.getdataerror()
        # 8. Pass Erroneous data and send to dataerrormanager for processing.
        data_error_manager.process(bad_data)

        # 9. Get All data which needs to be investigated.
        self.investigate_data = rulesexecutor.getinvestigatedata()
        # 10. Send data which needs to be investigated to investigatedatamanager for processing.
        investigate_data_manager.process(self.investigate_data)

        # 11. Get All records with Bad addresses
        bad_addresses = rulesexecutor.getbadaddress()
        # 12. Send All records with Bad addresses to badaddressmanager for processing.
        bad_address_manager.process(bad_addresses)

        # 13. Get All records with Env Portal Error.
        env_data_portal = rulesexecutor.getdata_with_portalenv_errors()
        # 14. Send All records with Env Portal Error to env_data_portal_manager for processing.
        env_data_portal_manager.process(env_data_portal)

        # 15. Get All records with  Backend enviornment errors.
        self.env_data_backend = rulesexecutor.getdata_with_backendenv_errors()

        # 16. Send All records with Backend enviornment  to env_data_backend_manager for processing.
        env_data_backend_manager.process(self.env_data_backend)

    """
       Phase3 : Searching defects based on errors.
    """
    @classmethod
    def phase3(self):
        defect_ref_manager = io_manager.getRecordManager('defect') #Defect manager instance.
        env_data_backend_manager = io_manager.getRecordManager('env_error_backend') #Env error backend instance.
        investigate_data_manager = io_manager.getRecordManager('investigatedata') #Env error instance
        analysis_engine_tx_ref = analysis_engine_tx_object.analysis_engine_tx_object()#Object for processing transactions.

        if len(self.investigate_data) > 0: #Run if we  have records which we need to investigate.
            analysis_engine_tx_ref.set_records(self.investigate_data) #Add investigate records in object.
            analysis_engine_tx_ref.set_records(defect_ref_manager.process_records(analysis_engine_tx_ref)) #Process investigate records for defect searching.

            if len(defect_ref_manager.search_defects())>0:
                self.investigate_data = defect_ref_manager.search_defects() #Search defects for provided investigate records.

        investigate_data_manager.process(self.investigate_data) #Process investigate records for generating report.

        if len(self.env_data_backend) > 0:
            analysis_engine_tx_ref.set_records(self.env_data_backend) #Add  records with Env-BackEnd  error in object.
            analysis_engine_tx_ref.set_records(defect_ref_manager.process_records(analysis_engine_tx_ref)) #Process records with Env-BackEnd  error for defect searching.

            if len(defect_ref_manager.search_defects()) > 0:
                self.env_data_backend = defect_ref_manager.search_defects() #Search defects for provided records with Env-BE error records.

        env_data_backend_manager.process(self.env_data_backend)#Process  records with Env-BackEnd  error for generating report.

        self.defect_stats = defect_ref_manager.percentage_defect_hit(self.investigate_data,self.env_data_backend)

    @classmethod
    def address_report(self):
        addressdata = io_manager.getRecordManager('addressdata')
        addressdata.free_address()
        result_data  = addressdata.query_data()
        addressdata.process(result_data)