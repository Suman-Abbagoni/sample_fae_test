"""
Searching Phrase dictionary from fail records and return phrase(s).
"""

from util import config_parser

class search_engine:

    #Searching failed value in Phrase dictionary.
    @classmethod
    def search_phrase_dict(self,phase2_tx_ref):

        #Getting processed data from phrase dictionary based on fail records and adding in object.
        phase2_tx_ref.set_records(self.get_simplified_data(phase2_tx_ref.get_records()))

        #Retruning value to analysis engine.
        return phase2_tx_ref


    # Searching failed value in Phrase dictionary and return rules.
    @classmethod
    def get_simplified_data(self,fail_list_value):

        #Instance list variable.
        catalog={}

        #Iterate through all fail records and search them in phrase dictionary.
        for fail_value in fail_list_value:
            # Converting data to String only(Might have to change logic here.)
            fail_value_error_msg = str(fail_value.rstrip("\n").split(";")[8:])


            # Search phrase in file.
            flag_data = self.search_file(fail_value_error_msg)

            # if "Several failures occurred" in fail_value_error_msg :
            #     catalog[fail_value.rstrip("\n")] = "nomatch"
            # elif flag_data != False :
            if flag_data != False:
                catalog[fail_value.rstrip("\n")] =  flag_data #Append to dictionary if fail error message  found in file.
            else:
                catalog[fail_value.rstrip("\n")] = "nomatch" #Appending nomatch string with delimeter if fail error message not found in file.

        return  catalog  # Returning dictionary with different test case records and phrases..

    # Searching file for phrase matching fail records.
    @classmethod
    def search_file(self,fail_value_temp):

        file_obj = open(config_parser.parser("General", "phrase_dictionary"), "r")#Opening phrase dictionary
        flag_data= []
        for file_value in file_obj: #Search file for phrases.
            search_value = str(":".join(file_value.split(":")[4:])).rstrip("\n") #Formatting and Modifying Search value.

            if  search_value.upper() in fail_value_temp.upper():
                flag_data.append(file_value)
                #file_obj.close() #Closing phrase dictionary



        file_obj.close()#Closing phrase dictionary if no value found.

        if len(flag_data) > 1:
            for data in flag_data:
                if "DATA:" in data:
                    priority_flag = data
                    return priority_flag
            for data in flag_data:
                if "ENV:PORTAL" in data:
                    priority_flag = data
                    return priority_flag
            for data in flag_data:
                if "ENV:BACKEND" in data:
                    priority_flag = data
                    return priority_flag
        elif len(flag_data) > 0:
            return flag_data.__getitem__(0)
        else:
            return False #return False if nothing found.
