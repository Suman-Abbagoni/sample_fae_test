"""
Managing Report , file and Dictionary of Bad Address.
"""
import datetime
from util import config_parser
from util.logger_util import logger_util
from global_var import address_dict
from collections import OrderedDict
from reporting.create_html import create_html
import  calendar

class badaddress_manager(object):

    #List for records with Bad Address
    catalog = []
    # contains the filepath of  file having  Bad Addresses.
    catalog_attachment = ''
    city_name='' #Variable for storing cicty name.

    # Pushing records with Bad Address in catalog.
    def process(self, list):
        self.catalog = list

    #Load from disk.
    def load(self, filename):
        self.catalog = [] #Empty catalog.
        address_file_obj = open(filename, "r") #Open file.

        for data in address_file_obj:
            self.catalog.append(data) # Put all file records into list from file.

        address_file_obj.close() #Close file.

    # Append method will append data in filename provided in parameter and will provide attachment.
    def write(self, filename):
        file_append = open(filename, "a+")  # Open file in Append mode.

        for record in self.catalog:
            try:
                self.city_name = address_dict.get(record.split(";")[7])#Pick locationid from dictionary
            except:
                self.city_name = "None" #Pass as None if locationID is not present in DB.
            file_append.write(str(datetime.datetime.now()) + ";" + config_parser.parser("General", "Env") + ";" + config_parser.parser(
                "General", "Release") + ";" +  config_parser.parser("General", "Cycle") + ";" + str(self.city_name) + ";" + str(record).replace('\n','') + '\n')  # Write records in file and change line.
        file_append.close()  # Close file

        self.catalog_attachment = filename  # File to be attached in email.

    #Clear all data from file.
    def clear(self):
        address_file_obj = open(self.catalog_attachment, 'r+') #Opening file.
        address_file_obj.truncate(0)  # Clearing file.
        address_file_obj.close()  # Closing file.

        # Return file to be attached.
    def get_attachment(self):
        return self.catalog_attachment

    #Comparing Threashold value with Address file size , Returning Boolean flag
    def address_email_report(self):
        if len(self.catalog) >= int(config_parser.parser('Address_check','threshold_value')) : #Checking if file length exceeds threshold value.
            return True #return True

        return False #return False if file length is not more than  threshold value.

    #Return Subject.
    def get_subject(self):
        subject =  "TTA - " +  str(calendar.month_name[int(config_parser.parser("General","Release").split(".")[1])])[0:3] + " " + \
        str(config_parser.parser("General","Release").split(".")[0]) + " Release - "+ config_parser.parser("General", "Env") + " - " + \
        str(config_parser.parser("General", "Cycle"))  + " - Bad Data - please resolve."
        return subject

    # Creating report format.

    def report_creation(self):
        try:
            self.load(self.catalog_attachment)  # Load file in catalog.
        except IOError as ex:
            logger_util.add_logger().error("===Bad Address file not present===" + str(ex))  # Handling filenotfound/IO exception.

        data_dictionary = OrderedDict()
        if len(self.catalog) <= 0:
            data_dictionary.setdefault("Test Suite", [])
            data_dictionary.setdefault("Test Case", [])
            data_dictionary.setdefault("Status", [])
            data_dictionary.setdefault("Email", [])
            data_dictionary.setdefault("Location", [])
            data_dictionary.setdefault("City", [])
            data_dictionary.setdefault("Error", [])

        for line in self.catalog:
            # Picking data based on ';' delimeter.
            row = line.split(";")
            data_dictionary.setdefault("Test Suite", []).append(row[6].replace('_Control',''))
            data_dictionary.setdefault("Test Case", []).append(row[8])
            status  = row[10]
            error = str(row[14:])
            if status == "PASS":
                error = error.replace("'None\\n'", "")
            status = '<p style="font-weight: bold ; color:#006400">%s</p>' % status
            if status == "FAIL":
                status = '<p style="font-weight: bold ; color:#8B0000">%s</p>' % status
            data_dictionary.setdefault("Status", []).append(status)
            data_dictionary.setdefault("Email", []).append(row[11])
            locationID = row[12]
            try:
                self.city_name = address_dict.get(locationID)  # Pick locationid from dictionary
            except:
                self.city_name = "None"  # Pass as None if locationID is not present in DB.
            data_dictionary.setdefault("Location", []).append(locationID)
            data_dictionary.setdefault("City", []).append(self.city_name)
            data_dictionary.setdefault("Error", []).append(error)  # Picking all data as it is error message and might have ';' in it.
        return create_html.html_template(data_dictionary, len(self.catalog), "Bad Data/Address ","background:#90EE90;color:#ffffff")