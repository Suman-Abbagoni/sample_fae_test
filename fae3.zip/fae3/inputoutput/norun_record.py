"""
"""




class norun_record(object):

    """
    """

    def __init__(self):
        object = self

