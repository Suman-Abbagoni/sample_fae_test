"""
Report generation for Prod Read Only Report only.
"""

from util import config_parser
from global_var import tab_name
import calendar
from collections import OrderedDict
from reporting.create_html import create_html

class proddata_manager(object):


    temp_dict = {}

    #Return subject after tweaking.
    def get_subject(self,subject):
        return subject.replace(
            calendar.month_name[int(config_parser.parser("General", "Release").split(".")[1])],
            calendar.month_name[int(config_parser.parser(tab_name, "Release").split(".")[1])], 1).replace(
            config_parser.parser("General", "Release").split(".")[0],
            config_parser.parser(tab_name, "Release").split(".")[0], 1).replace(tab_name, "", 1)

    #Keeping records in dict from file.
    @classmethod
    def process(self,filename):
        filename_in = open(filename, "r")
        for data in filename_in:
            self.temp_dict[data.split(";")[2]] = data
        filename_in.close()

    # Writing result to HTML.
    @classmethod
    def generate_html_result(self,input_File):

        self.process(input_File)
        data_dictionary = OrderedDict()

        if len(self.temp_dict) <= 0:
            data_dictionary.setdefault("Status", [])
            data_dictionary.setdefault("Test Case Name", [])
            data_dictionary.setdefault("Description", [])
            data_dictionary.setdefault("Portal", [])
            data_dictionary.setdefault("Success Criteria", [])
            data_dictionary.setdefault("Error", [])


        for key in sorted(self.temp_dict.iterkeys(), key=lambda x: (x.split("-")[2]), reverse=True):

            # Picking data based on ';' delimeter.
            row = self.temp_dict[key].split(";")
            status = row[4]
            error = str(row[8:])
            if status == "PASS":
                error = error.replace("'None\\n'", "")
            status = '<p style="font-weight: bold ; color:#006400">%s</p>' % status
            if status == "FAIL":
                status = '<p style="font-weight: bold ; color:#8B0000">%s</p>' % status

            data_dictionary.setdefault("Status", []).append(status)
            data_dictionary.setdefault("Test Case Name", []).append(row[2])
            data_dictionary.setdefault("Description", []).append(row[0])
            data_dictionary.setdefault("Portal", []).append(row[5])
            data_dictionary.setdefault("Success Criteria", []).append(row[6])
            data_dictionary.setdefault("Error", []).append(error)  # Picking all data as it is error message and might have ';' in it.
        return create_html.html_template(data_dictionary, "null" , "Prod Data")