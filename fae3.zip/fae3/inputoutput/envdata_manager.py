
class envdata_manager(object):

    def __init__(self):
        pass