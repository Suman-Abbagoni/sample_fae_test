"""
Managing Dictionary of Fail Records.
"""

import fail_record
from util.helper import helper
from util import  config_parser
from collections import OrderedDict
from reporting.create_html import create_html

class fail_manager(object):

	# contains the catalog of fail records
	catalog = []

	#Pushing fail records in catalog.
	def process(self, list):
		self.catalog = list
		self.catalog = helper.phase1_sort_list(self.catalog)

	# load records from file into the catalog
	def load(self, filename):
		pass

	# write the fail catalog to disk
	def write(self, filename):
		disk_file = open(filename,"w") #Opening file
		for value in self.catalog: #Writing data in file from catalog.
			disk_file.write(value)
		disk_file.close() #Closing file.

	def report_creation(self):

		data_dictionary = OrderedDict()
		if len(self.catalog) <=0:
			data_dictionary.setdefault("Test Suite", [])
			data_dictionary.setdefault("Test Case", [])
			data_dictionary.setdefault("Status", [])
			data_dictionary.setdefault("Email", [])
			data_dictionary.setdefault("Location", [])
			data_dictionary.setdefault("Error", [])

		for line in self.catalog:
			# Picking data based on ';' delimeter.
			row = line.split(";")
			data_dictionary.setdefault("Test Suite",[]).append(row[0].replace('_Control',''))
			data_dictionary.setdefault("Test Case",[]).append(row[2])
			status = row[4]
			error = str(row[8:])
			if status == "PASS":
				error = error.replace("'None\\n'", "")
			status = '<p style="font-weight: bold ; color:#006400">%s</p>' % status
			if status == "FAIL":
				status = '<p style="font-weight: bold ; color:#8B0000">%s</p>' % status
			data_dictionary.setdefault("Status",[]).append(status)
			data_dictionary.setdefault("Email",[]).append(row[5])
			data_dictionary.setdefault("Location",[]).append(row[6])
			data_dictionary.setdefault("Error",[]).append(error)  # Picking all data as it is error message and might have ';' in it.

		return create_html.html_template(data_dictionary,len(self.catalog),"Fail ","background:#CD5C5C;color:#ffffff")