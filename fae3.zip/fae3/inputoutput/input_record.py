"""
"""




class input_record(object):

    """
    """

    def __init__(self):
        object = self

