"""
Managing Dictionary , Report and file of Records with Portal-env related errors.
"""

import datetime
from util import config_parser
from util.helper import helper
from global_var import address_dict
from collections import OrderedDict
from reporting.create_html import create_html


class envdata_portal_manager(object):


    # contains the catalog of Erroneous Data Records.
    catalog = []
    # contains the filepath  of  file with Erroneous Data Records.
    catalog_attachment = ''
    city_name = ''  # Variable for storing city name.

    # Pushing Erroneous Data Records. in catalog.
    def process(self, list):
        self.catalog = list
        self.catalog = helper.phase2_sort_list(self.catalog)

    # load Erroneous Data Records from file into the catalog
    def load(self, filename):
        pass

    # Append method will append data in filename provided in parameter
    def write(self, filename):
        for record in self.catalog:
            try:
                self.city_name = address_dict.get(record.split(";")[7])  # Pick locationid from dictionary.
            except:
                self.city_name = "None"  # Pass as None if locationID is not present in DB.
            file_append = open(filename, "a+")  # Open file in Append mode.
            file_append.write(str(datetime.datetime.now()) + ";" + config_parser.parser("General",
                                                                                        "Env") + ";" + config_parser.parser(
                "General", "Release") + ";" + config_parser.parser("General", "Cycle") + ";" + str(
                self.city_name) + ";" + record + '\n')  # Write records and change line.
            file_append.close()  # Close file

        self.catalog_attachment = filename  # File to be attached in email.

    # Return file to be attached.
    def get_attachment(self):
        return self.catalog_attachment


    def report_creation(self):

        data_dictionary = OrderedDict()
        if len(self.catalog) <= 0:
            data_dictionary.setdefault("Test Suite", [])
            data_dictionary.setdefault("Test Case", [])
            data_dictionary.setdefault("Status", [])
            data_dictionary.setdefault("Email", [])
            data_dictionary.setdefault("Location", [])
            data_dictionary.setdefault("City", [])
            data_dictionary.setdefault("Phrase", [])
            data_dictionary.setdefault("Error", [])

        for line in self.catalog:
            # Picking data based on ';' delimeter.
            row = line.split(";")
            data_dictionary.setdefault("Test Suite", []).append(row[1].replace('_Control',''))
            data_dictionary.setdefault("Test Case", []).append(row[3])
            status = row[5]
            error = str(row[9:])
            if status == "PASS":
                error = error.replace("'None\\n'", "")
            status = '<p style="font-weight: bold ; color:#006400">%s</p>' % status
            if status == "FAIL":
                status = '<p style="font-weight: bold ; color:#8B0000">%s</p>' % status
            data_dictionary.setdefault("Status", []).append(status)
            data_dictionary.setdefault("Email", []).append(row[6])
            locationID = row[7]
            data_dictionary.setdefault("Location", []).append(locationID)

            try:
                self.city_name = address_dict.get(locationID)  # Pick locationid from dictionary
            except:
                self.city_name = "None"  # Pass as None if locationID is not present in DB.
            data_dictionary.setdefault("City", []).append(self.city_name)
            data_dictionary.setdefault("Phrase", []).append(row[0])
            data_dictionary.setdefault("Error", []).append(error)  # Picking all data as it is error message and might have ';' in it.
        return create_html.html_template(data_dictionary, len(self.catalog), "Portal ","background:#FFE4C4;color:#ffffff")