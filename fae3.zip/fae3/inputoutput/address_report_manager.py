"""
Running SQL queries.
Processing SQL data.
Writing email to file and reusing it.
"""

import datetime
from util import config_parser ,helper
from util.sql_helper import sql_helper
import os

class address_report_manager(object):
    schema = config_parser.parser("Address_Status_Report", "schema") # Picking schema from config.
    env = schema.split('_')[2] #Creating env for subject from schema.
    subject = "Daily Status of Addresses  " + env + " " + str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M")) #Subject line for email.
    zipfilepath = str("\\".join(config_parser.parser("Address_Status_Report","zip_file_path").split("\\")[:-1])) + "\\[ " + str(datetime.datetime.now().strftime("%Y-%m-%d")) + " ] " + str(config_parser.parser("Address_Status_Report","zip_file_path").split("\\")[-1])
    catalog = [] #Empty list for processing data.

    def process(self,resultdata):
        self.catalog = resultdata #Assigning data to list.

    def query_data(self): #Pick data from SQL and process it.
        # Select Querie(s)
        queries = []
        queries.append("select type as Type ,  count(used) as Total, sum(CASE WHEN used = 'f' THEN 1 ELSE 0 END)  as Free from " + self.schema + ".ta_falcon_address where type in ('DSC_WO','DSC_WC') group by  type order by type;")
        queries.append( "select type as Type , CITY as City , count(used) as Total, sum(CASE WHEN used = 'f' THEN 1 ELSE 0 END)  as Free from   " + self.schema + ".ta_falcon_address group by city  , type order by type;")

        resultdata = sql_helper.select_query(queries)
        return  resultdata #Returning data.


    def free_address(self): #Free SQL data.
        # Update Querie(s)
        update_query = []
        update_query.append("update  " + self.schema + ".ta_falcon_address set used = 'f' where  used = 'r';")
        count = sql_helper.update_query(update_query)
        return  count #Returning count after updating query execution.

    def email_report(self): #Create email report.
        new_line = "\n"
        text = new_line

        for data in self.catalog:
            if  any(isinstance(i, tuple) for i in data) == True:
                for row in data :
                    text = text +'|'.join(str(e) for e in row) + new_line
                text = text +new_line

            if  any(isinstance(i, tuple) for i in data) == False:
                text = text + '|'.join(str(e) for e in data)+new_line
        self.catalog = text
        filename = config_parser.parser("Address_Status_Report","file_email_address")
        if os.path.exists(filename):
            with open(filename,"r") as address_report_file:
                text = text + address_report_file.read()

        return text #Returning email report.

    def get_attachment(self): #Pick all zip files as attachment for backup.

        zipfile =  config_parser.parser("Address_Status_Report", "zip_files") #Picking files to zip from config file.
        zipfilenames=[]

        for filename in zipfile.split(","):
            zipfilenames.append(filename)

        helper.helper.zip_file(self.zipfilepath,zipfilenames)

        return self.zipfilepath

    def clean(self): #Delete zip file after sending email.
        if os.path.exists(self.zipfilepath):
            os.remove(self.zipfilepath)

    def write_to_disk(self,filename): #Writing email to file so it can be reused.
        if os.path.exists(filename) == False:
            with open(filename, "w") as file_email:pass

        with open(filename,"r+") as file_email:
            old_data = file_email.read()
            file_email.seek(0)
            file_email.write("-----Original Message-----\n")
            file_email.write("Sent:" + str(datetime.datetime.now().strftime("%B %d,%Y %H:%M %p")) +"\n")

            file_email.write(self.subject)
            file_email.write(self.catalog)
            file_email.write(old_data)