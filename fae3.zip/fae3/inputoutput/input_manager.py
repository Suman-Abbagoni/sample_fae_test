"""
Manging dictionary :
Creating Catalog after  Reading from disk.
Writing to master_file(disk) from Catalog
"""

import os
import datetime
from util import config_parser

class input_manager(object):

	# contains the catalog of input records
	catalog = list()

	#contains header of  input/master file.
	#test_file_header =''



	# build a dictionary of pass records and pass it back to analysis_engine.
	def getPassDictionary(self):

		pass_catalog= list() # contains the catalog of pass records

		#Iterating through input catalog and pushing only pass records in pass catalog.
		for pass_value in self.catalog:
			if ("PASS" in pass_value):
				pass_catalog.append(pass_value)

		pass_catalog = sorted(pass_catalog, key=lambda x: (x.split(";")[0])) #Sorted based on test-suite

		return pass_catalog

	# build a dictionary of fail records and pass it back to analysis_engine.
	def getFailDictionary(self):

		fail_catalog = [] # contains the catalog of fail records

		# Iterating through input catalog and pushing only fail records in fail catalog.
		for fail_value in self.catalog:
			if ("FAIL" in fail_value and 'Dictionary does not contain key' not in fail_value):
				fail_catalog.append(fail_value)

		fail_catalog = sorted(fail_catalog, key=lambda x: (x.split(";")[0])) #Sorted based on test-suite

		return fail_catalog

	# build a dictionary of no-run records and pass it back to analysis_engine.
	def getNoRunDictionary(self):

		norun_catalog = [] # contains the catalog of no-run records

		# Iterating through input catalog and pushing only no-run records in no-run catalog.
		for norun_value in self.catalog:
			if ("FAIL" in norun_value and 'Dictionary does not contain key' in norun_value):
				norun_value = norun_value.replace('FAIL','No-Run') #Replacing fail with no-run
				norun_catalog.append(norun_value)

		norun_catalog = sorted(norun_catalog, key=lambda x: (x.split(";")[0])) #Sorted based on test-suite

		return norun_catalog


	# load records from file into the catalog using filename
	def load(self, filename):

		list_input = list()  #For Loading input data from file.

		input_file = open(filename, "r") #Open file.
		lines = input_file.readlines() #Read all lines from file.
		#self.test_file_header = lines[0] #Storing header of file

		i = 1
		# Processing for having one record in one line only.

		while i < len(lines):

			if ("PASS" in lines[i] or "FAIL" in lines[i]):
				self.catalog.append(lines[i])

			else:
				s = len(self.catalog) - 1
				self.catalog[s] = self.catalog[s] + lines[i]

			i = i + 1

		input_file.close() #Closing file.

		#Removing Unwanted values from catalog[]
		for list_str in self.catalog[:]:
			if ('Promotions_Discounts_Control' in list_str and 'PASS' in list_str):
				self.catalog.remove(list_str)
			if ('Customer_Contacts_Control' in list_str):
				self.catalog.remove(list_str)

	# Append the record catalog to disk on masterfilename
	def append(self, filename):

		file_master =  open (filename, "a+") #Open file in Append mode.



			#Formatting and writing data.
		for data in self.catalog:
			if ("FAIL" in data and 'Dictionary does not contain key' in data):
				data = data.replace('FAIL', 'No-Run')  # Replacing fail with no-run
			data = data.replace('\n', ' ')
			file_master.write(str(datetime.datetime.now()) + ";" + config_parser.parser("General","Env") + ";" + config_parser.parser("General","Release") + ";" +
							  config_parser.parser("General","Cycle") + ";" + data )
			file_master.write("\n")
		file_master.close() #Closing file