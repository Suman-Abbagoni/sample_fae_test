"""
Managing Dictionary of Pool Records.
Loading and Writing records from/to disk.
These records will be reused(as seed data) for performing Modify/Disconnect later.
"""

from util import config_parser
import datetime
from ConfigParser import NoSectionError
from ConfigParser import NoOptionError
from global_var import tab_name
from collections import OrderedDict
from reporting.create_html import create_html

class order_reuse_pool_manager(object):

	# contains the catalog of pool records
	catalog = []

	# Pushing pool records in catalog.
	def process(self, list):
		try:
			order_pool_reuse_flag = config_parser.parser(tab_name, "reuse_flag")  # Deciding based on tab name.
			if order_pool_reuse_flag == 'True':  # Validating if flag is enabled or disabled.
				self.catalog = list
		except (NoSectionError, NoOptionError):  # Clearing catalog if section not present in config.
			self.catalog = []
		self.catalog = sorted(self.catalog, key=lambda x: (x.split(";")[6]))


	# load pool  records from file into the catalog
	def load(self, filename):
		self.catalog = []  # Clearing catalog before updating records.
		record_pool_file = open(filename, "r")  # Opening file in Read mode.
		record_lines = record_pool_file.readlines()  # Reading all lines from file.
		for pool_record in record_lines:
			self.catalog.append(pool_record)  # Appending all records in catalog[]
		record_pool_file.close()  # Closing file
		self.catalog = sorted(self.catalog, key=lambda x: (x.split(";")[6]))


	# Append the record catalog to disk on resue_pool file.
	def write(self, filename):
		file_master = open(filename, "a+")  # Open file in Append mode.
		if len(self.catalog) > 0:
			# Formatting and writing data.
			for data in self.catalog:
				file_master.write(str(datetime.datetime.now()) + ";" + config_parser.parser("General","Env") + ";" + config_parser.parser("General", "Release") + ";" + config_parser.parser("General", "Cycle") + ";" + data)
			# file_master.write("\n")
			file_master.close()  # Closing file

	# Writing pool records result to HTML and returning to report_manager
	def report_creation(self):
		self.load(config_parser.parser("General","order_reuse_file_path"))  # Picking file from config and loading data in it.
		data_dictionary = OrderedDict()

		if len(self.catalog) <= 0:
			data_dictionary.setdefault("Test Suite", [])
			data_dictionary.setdefault("Test Case", [])
			data_dictionary.setdefault("Status", [])
			data_dictionary.setdefault("Email", [])
			data_dictionary.setdefault("Location", [])
			data_dictionary.setdefault("Error", [])

		for line in self.catalog:
			# Picking data based on ';' delimeter.
			row = line.split(";")
			data_dictionary.setdefault("Test Suite",[]).append(row[4].replace('_Control',''))
			data_dictionary.setdefault("Test Case",[]).append(row[6])
			status = row[8]
			error = str(row[12:])
			if status == "PASS":
				error = error.replace("'None\\n'", "")
			status = '<p style="font-weight: bold ; color:#006400">%s</p>' % status
			if status == "FAIL":
				status = '<p style="font-weight: bold ; color:#8B0000">%s</p>' % status
			data_dictionary.setdefault("Status",[]).append(status)
			data_dictionary.setdefault("Email",[]).append(row[9])
			data_dictionary.setdefault("Location",[]).append(row[10])
			data_dictionary.setdefault("Error",[]).append(error)  # Picking all data as it is error message and might have ';' in it.
		return create_html.html_template(data_dictionary,len(self.catalog),"Provides Pool ","background:#90EE90;color:#ffffff")