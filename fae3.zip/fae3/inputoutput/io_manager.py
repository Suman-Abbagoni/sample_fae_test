"""
Managing Input and output files.
Managing References of Records.
"""

import pass_manager
import fail_manager
import norun_manager
import input_manager
import baddata_manager
import badaddress_manager
import investigatedata_manager
import order_reuse_pool_manager
import proddata_manager
from defect import defect_engine
import address_report_manager
import envdata_portal_manager
import envdata_backend_manager
from util import config_parser
from rules import rules_executor
import defect_manager

class io_manager(object):
    catalog = {} # Contains a dictionary of references to record managers

    abs_path = config_parser.parser("General","data_path")  # Picking Absolute path for reading and writing files from disk.

    # write all record managers currently contained in the self.catalog[] to disk for Phase1
    # for each record manager in self.catalog[], write to disk
    @classmethod
    def phase1_write_to_disk(self):

        self.catalog.get('fail').write(self.abs_path  + "fail.csv")
        self.catalog.get('pass').write(self.abs_path  + "pass.csv")
        self.catalog.get('norun').write(self.abs_path  + "norun.csv")
        self.catalog.get('order_reuse').write(config_parser.parser("General","order_reuse_file_path"))

    # write all record managers currently contained in the self.catalog[] to disk for Phase2
    # for each record manager in self.catalog[], write to disk
    @classmethod
    def phase2_write_to_disk(self):
        abs_path_phase2 = config_parser.parser("General","phase2_data_path")  # Picking Absolute path for reading and writing files from disk.
        self.catalog.get('dataerror').write(abs_path_phase2 + "dataerror_master.csv")
        if config_parser.parser("General", "master_file_flag").upper() == 'TRUE':
            self.catalog.get('investigatedata').write(abs_path_phase2 + "investigate_master.csv")
        self.catalog.get('badaddress').write(abs_path_phase2  + "badaddress_master.csv")
        self.catalog.get('env_error_portal').write(abs_path_phase2 + "env_error_portal_master.csv")
        self.catalog.get('env_error_backend').write(abs_path_phase2 + "env_error_backend_master.csv")

    @classmethod
    def address_report_clean_and_write(self):
        self.catalog.get("addressdata").clean()
        self.catalog.get("addressdata").write_to_disk(config_parser.parser("Address_Status_Report","file_email_address"))


    # return the record manager associated with the label
    @classmethod
    def getRecordManager(self, label):
        return self.catalog.get(label)

    #Phase1 Setup , loading input file and storing refrences in self.catalog[].
    @classmethod
    def phase1_setup(self):

        # ensure the catalog is empty
        self.catalog = {}

        # load the input manager
        inputManager = input_manager.input_manager()

        # load records in inputmanager's Catalog[]
        inputManager.load(self.abs_path  + "results.txt")
        self.catalog["input"] = inputManager
        self.getRecordManager("input")

        # load the pass manager reference in catalog[]
        passManager = pass_manager.pass_manager()
        self.catalog["pass"] = passManager

        # load the fail manager reference in catalog[]
        failManager = fail_manager.fail_manager()
        self.catalog["fail"] = failManager

        # load the norun manager reference in catalog[]
        norunManager = norun_manager.norun_manager()
        self.catalog["norun"] = norunManager

        # load the order_reuse_pool_manager manager reference in catalog[]
        orderreusepoolmanager = order_reuse_pool_manager.order_reuse_pool_manager()
        self.catalog["order_reuse"] = orderreusepoolmanager

    #Writing data for Phase1b into disk from catalog[]
    @classmethod
    def write_master_file(self):
        if config_parser.parser("General","master_file_flag").upper() == 'TRUE':
            #Creating file_name for storing data in master file.
            file_name = config_parser.parser("General","master_file_path")
            self.catalog.get("input").append(file_name) #Writing to file.


    @classmethod
    def phase2_setup(self):

        # load the baddata manager reference in catalog[]
        bad_data_manager = baddata_manager.baddata_manager()
        self.catalog["dataerror"] = bad_data_manager

        # load the investigatedata_manager  reference in catalog[]
        investigate_data_manager = investigatedata_manager.investigatedata_manager()
        self.catalog["investigatedata"] = investigate_data_manager

        # load the reles_executor  reference in catalog[]
        rulesexecutor = rules_executor.rules_executor()
        self.catalog["rulesexecutor"] = rulesexecutor

        # load the badaddress_manager  reference in catalog[]
        bad_address_manager = badaddress_manager.badaddress_manager()
        self.catalog["badaddress"] = bad_address_manager

        # load the envdata_portal_manager  reference in catalog[]
        env_data_portal_manager = envdata_portal_manager.envdata_portal_manager()
        self.catalog["env_error_portal"] = env_data_portal_manager

        # load the envdata_backend_manager  reference in catalog[]
        env_data_backend_manager = envdata_backend_manager.envdata_backend_manager()
        self.catalog["env_error_backend"] = env_data_backend_manager

    @classmethod
    def phase3_setup(self):

        # load the defect_manager  reference in catalog[]
        defect_ref_manager = defect_engine.defect_engine()
        self.catalog["defect"] = defect_ref_manager

        defect_records_ref_manager = defect_manager.defect_manager()
        defect_records_ref_manager.load(config_parser.parser('Defect_search', 'defect_file') )
        self.catalog["defect_records"] = defect_records_ref_manager

    @classmethod
    def prod_setup(self):
        # load the proddata manager reference in catalog[]
        proddata = proddata_manager.proddata_manager()
        self.catalog["proddata"] = proddata

        # load the input manager
        inputManager = input_manager.input_manager()

        # load records in inputmanager's Catalog[]
        inputManager.load(self.abs_path + "results.txt")
        self.catalog["input"] = inputManager

    @classmethod
    def address_report_setup(self):
        # load the address report manager reference in catalog[]
        self.catalog["addressdata"] = address_report_manager.address_report_manager()