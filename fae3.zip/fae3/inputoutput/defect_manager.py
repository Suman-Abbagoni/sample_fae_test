"""
Managing Dictionary , Report and file of Records with Portal-env related errors.
"""

import datetime
from util import config_parser
from global_var import address_dict
from collections import OrderedDict
from reporting.create_html import create_html
from util.helper import helper


class defect_manager(object):


    # contains the catalog of Erroneous Data Records.
    catalog = list()
    header=''

    # Pushing Erroneous Data Records. in catalog.
    def process(self, list):
        pass


    # load Erroneous Data Records from file into the catalog
    def load(self, defect_file):
        with open(defect_file,"r") as defect_Files:
            self.header = defect_Files.readline()
            n = len(self.header.split("|")) - 1
            self.header = ";".join(self.header.split("|")[1:n])
            for data in defect_Files:
                if "Telus Test Automation" in data.split("|")[11]:
                    n =  len(data.split("|")) -1
                    self.catalog.append(";".join(data.split("|")[1:n]))


    # Append method will append data in filename provided in parameter
    def write(self, filename):
        pass

    # Return file to be attached.
    def get_attachment(self):
        pass


    def report_creation(self):
        data_dictionary = OrderedDict()

        if len(self.catalog) <= 0:
            for data in self.header.split(";"):
                data_dictionary.setdefault(data.replace("  ",""), [])
        for data in self.catalog:
            data_dictionary.setdefault(self.header.split(";")[0].replace("  ", ""), []).append(data.split(";")[0])
            data_dictionary.setdefault(self.header.split(";")[1].replace("  ",""), []).append(data.split(";")[1])
            data_dictionary.setdefault(self.header.split(";")[2].replace("  ", ""), []).append(data.split(";")[2])
            data_dictionary.setdefault(self.header.split(";")[3].replace("  ", ""), []).append(data.split(";")[3])
            data_dictionary.setdefault(self.header.split(";")[4].replace("  ", ""), []).append(data.split(";")[4])
            data_dictionary.setdefault(self.header.split(";")[5].replace("  ", ""), []).append(data.split(";")[5])
            data_dictionary.setdefault(self.header.split(";")[6].replace("  ", ""), []).append(data.split(";")[6])
            data_dictionary.setdefault(self.header.split(";")[7].replace("  ", ""), []).append(data.split(";")[7])
            data_dictionary.setdefault(self.header.split(";")[8].replace("  ", ""), []).append(data.split(";")[8])
            data_dictionary.setdefault(self.header.split(";")[9].replace("  ", ""), []).append(data.split(";")[9])
            data_dictionary.setdefault(self.header.split(";")[10].replace("  ", ""), []).append(data.split(";")[10])

            #data_dictionary.setdefault(self.header.split(";")[1].replace("  ", ""), [])

        return create_html.html_template(data_dictionary, len(self.catalog), "Defects ")