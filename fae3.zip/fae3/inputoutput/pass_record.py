"""
"""




class pass_record(object):

    """
    """

    def __init__(self):
        object = self

