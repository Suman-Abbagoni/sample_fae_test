"""
Global variables which are used across FAE.
"""

import sys
from util import  config_parser
from util.sql_helper import  sql_helper

#Global Variables.
command = str(sys.argv[1]).lower() #Phase which will decide actions to be performed.
try:
    thread = sys.argv[2]  #No of threads  used for testing.
except:
    thread = "N/A" #In case of cleanup when argument is not passed

if (command == "addressreport"):
    tab_name = "Address_Status_Report"
else:
    try:
        tab_name = sys.argv[3] #Tab Name of Control file.
    except:
        tab_name = "N/A" #In case of cleanup when argument is not passed

try:
    filepath = sys.argv[4] #filename for padding - will be used once only.
except:
    filepath = "N/A" #Will be N/A always except when parameter is 'pad'.



#Pick city and location_id from file.
def map_city_locationID():
    temp={}
    
    catalog = sql_helper.select_query(["select location_id  , city from " + config_parser.parser("Address_Status_Report","schema") + ".ta_falcon_address;"])

    for data in catalog:
        if any(isinstance(i, tuple) for i in data) == True:
            for row in data:
                text = '|'.join(str(e) for e in row)
                temp[text.split("|")[0]] = text.split("|")[1]

        if any(isinstance(i, tuple) for i in data) == False:
            text = '|'.join(str(e) for e in data)
            temp[text.split("|")[0]] = text.split("|")[1]

    return temp

address_dict = map_city_locationID() #Dictionary for storing all cities corresponding to their locationID