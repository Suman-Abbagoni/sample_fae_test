"""
Archive master file(s) for a particular release after:
a. Scrubbing Error Messages in data , investigate  , test_result master files.
b. trimming data , investigate master file records.
"""

import os
import re
from util import config_parser

class archive(object):

    #Global variables.
    path = config_parser.parser('General', 'phase2_data_path') #Dir path of master files.
    archive_path = path + "archive\\" #Archive path of master files.
    catalog_master_archive = []
    catalog_master_scrubbed = []
    catalog_master_trimmed = []
    header_investigate = "datestamp;env;release;cycle;control_sheet;test_case_name;error_type;error_subtype;system_type;system_subtype;error_phrase;error_message\n"
    header_data = "datestamp;env;release;cycle;control_sheet;test_case_name;error_type;error_subtype;system_type;system_subtype;location;error_phrase\n"
    header_test_result = "datestamp;env;release;cycle;control_sheet;test_suite_name;test_case_name;seq;result;email;location_id;order_id;error_message\n"

    #Check if folder present else create it.
    def __init__(self):
        self.folder_check() #Creating archive folder if not present.

    #Clear files
    @classmethod
    def clean_files(self):
        files_to_clear = config_parser.parser("Archive_master_files","clear_files").split(",")
        for file in files_to_clear:
            self.clear_data(file)

    # Scrub and/or trim file(s)
    def scrub_trim_files(self):
        scrub_trim_files = config_parser.parser("Archive_master_files", "scrub_files").split(",") # Pick files to trim.

        for file in scrub_trim_files:
            #Pick records for this release.
            self.archive_master_files(file)
            #Trim records if file is not test_result_master.csv
            if file != "test_result_master.csv":
                self.trim(self.catalog_master_archive, file)
            else:
                self.catalog_master_trimmed = self.catalog_master_archive
            # Scrub error messages .
            self.fileparsing_and_scrubbing(self.catalog_master_trimmed)
            #Writing to Archive file.
            self.write_archive(file,self.catalog_master_scrubbed)
            #Clearing lists for new file.
            self.catalog_master_archive = []
            self.catalog_master_scrubbed = []
            self.catalog_master_trimmed = []


    #Checking archive folder , creating if not present.
    def folder_check(self):
        if not os.path.exists(self.archive_path):
            os.makedirs(self.archive_path)


    #Method for clearing all data from a file.
    @classmethod
    def clear_data(self,filename):
        with open(self.path + filename, 'w'): pass

    #Archive master file.
    def archive_master_files(self,filename):
        catalog_master = []

        if os.path.exists(self.path +  filename):
            with open(self.path +  filename, "r")  as master_file:  # Opening destination file in write mode.
                for master_data in master_file:

                    if config_parser.parser("Archive_master_files", "Env") + ";" + config_parser.parser("Archive_master_files","Release")  in master_data:
                        master_data_value = str(";".join(master_data.split(";")[0:2])) + ";'" + master_data.split(";")[2] + "';" + str(";".join(master_data.split(";")[3:]))
                        self.catalog_master_archive.append(master_data_value) #Data qualified for archiving.
                    else:
                        catalog_master.append(master_data) #Data which will stay intact.

    #Not deleting anything from master file for now.
    # with open(self.path + filename, "w")  as master_file:  # Opening destination file in write mode and writing archived data as well for now.
    #     for catatalog_data in catalog_master:
    #         master_file.write(catatalog_data)


    #Trim data accordingly.
    def trim(self,catalog,filename):

        for value in catalog:  # Processing file(s).

            if "dataerror_master" in filename: #Dataerror_master file
                record = str(";".join(value.split(";")[0:4])) + ";" + str(value.split(";")[6]) + ";" + str(value.split(";")[8]) + ";" +  str(";".join(value.split(";")[5].split(":")[0:4])) +  ";" + str(value.split(";")[4]) + ";" + str(value.split(";")[5].split(":")[4]) + "\n"
                self.catalog_master_trimmed.append(record)
            elif  "investigate_master" in filename: #Investigate_master file
                record = str(";".join(value.split(";")[0:4])) + ";" + str(value.split(";")[6]) + ";" + str(value.split(";")[8]) + ";ENV;NULL;NULL;NULL;NULL;" + str("".join(value.split(";")[14:]))
                self.catalog_master_trimmed.append(record)
            elif   "env_error_backend_" in filename:

                record = str(";".join(value.split(";")[0:4])) + ";" + str(value.split(";")[6]) + ";" + str(
                    value.split(";")[8]) + ";" + str(";".join(value.split(";")[5].split(":")[0:4])) + ";" + str(
                    value.split(";")[4]) + ";" + str(":".join(value.split(";")[5].split(":"))).replace(':',';',4)
                #print record
                self.catalog_master_trimmed.append(record)
            elif "env_error_portal_" in filename:
                record = str(";".join(value.split(";")[0:4])) + ";" + str(value.split(";")[6]) + ";" + str(
                    value.split(";")[8]) + ";" + str(";".join(value.split(";")[5].split(":")[0:4])) + ";" + str(
                    value.split(";")[4]) + ";" + str(value.split(";")[5].split(":")[4])
                self.catalog_master_trimmed.append(record)


    #Scrub data.
    def fileparsing_and_scrubbing(self,catalog_master):

        # Looping through input file and parsing data.
        for line in catalog_master:
            updatedLine = re.sub('\#\d{10}\s\d{19}', '"xxxxxx"', line.strip())
            updatedLine = re.sub('\"\d{19}\"', '"xxxxxx"', updatedLine)
            updatedLine = re.sub('\d{10,12}', '"xxxxxx"', updatedLine)
            updatedLine = re.sub('\(\d{2,4}, \d{2,4}\)', '{xx,xx)', updatedLine)
            updatedLine = re.sub('-0.\d{1,3}', '0.0', updatedLine)
            self.catalog_master_scrubbed.append(updatedLine + "\n")


    #Appending data to defined file.
    def write_archive(self,filename,catalog_write_file):
        with open(self.archive_path  + filename, "a") as master_file_archive:  # Opening destination file in append mode.
            for master_data_archive in catalog_write_file:
                master_file_archive.write(master_data_archive) #Append all records

    #Add value at certain location in defined filename in order to keep consistency.
    @classmethod
    def pad(self,offset,value,filepath):
        temp_catalog=[]

        file_data = open(filepath,"r")


        for data in file_data:
            if data  in self.header_test_result or data in  self.header_data or data in self.header_investigate:
                temp_catalog.append(data)
            else:
                temp_catalog.append(";".join(data.split(";")[0:int(offset)]) + ";" + value + ";" + ";".join(data.split(";")[int(offset):]))

        file_data.close()
        file_data = open(filepath, "w")
        for data in temp_catalog:
            file_data.write(data)